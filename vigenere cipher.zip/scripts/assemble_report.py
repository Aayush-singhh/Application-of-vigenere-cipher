# scripts/assemble_report.py
import os
import re

from report_data_part1 import FRONT_MATTER
from report_data_part2 import CHAPTERS_4_TO_6
from report_data_part3 import CHAPTERS_7_TO_9
from report_data_part4 import CHAPTERS_10_TO_END

def convert_markdown_to_academic_html(md_text):
    """
    Lightweight, deterministic Markdown-to-HTML converter customized for
    formal academic thesis printing (70+ pages) with A4 pagination, 
    running headers, footnotes, callouts, and clean typographic tables.
    """
    lines = md_text.split('\n')
    html_lines = []
    in_table = False
    in_code = False
    code_lang = ""
    table_header_done = False
    
    for line in lines:
        stripped = line.strip()
        
        # Handle explicit page breaks
        if '<div style="page-break-after: always;"></div>' in line:
            if in_table:
                html_lines.append("</table></div>")
                in_table = False
            html_lines.append('<div class="page-break"></div>')
            continue
            
        # Code blocks
        if stripped.startswith('```'):
            if not in_code:
                in_code = True
                code_lang = stripped[3:].strip()
                html_lines.append(f'<pre><code class="language-{code_lang}">')
            else:
                in_code = False
                html_lines.append('</code></pre>')
            continue
            
        if in_code:
            escaped = (line.replace('&', '&amp;')
                           .replace('<', '&lt;')
                           .replace('>', '&gt;'))
            html_lines.append(escaped)
            continue
            
        # Tables
        if stripped.startswith('|') and stripped.endswith('|'):
            cells = [c.strip() for c in stripped[1:-1].split('|')]
            if not in_table:
                in_table = True
                table_header_done = False
                html_lines.append('<div class="table-container"><table>')
                html_lines.append('<thead><tr>' + ''.join(f'<th>{c}</th>' for c in cells) + '</tr></thead><tbody>')
                table_header_done = True
                continue
            elif table_header_done and all(re.match(r'^:?-+:?$', c) for c in cells):
                # Delimiter line
                continue
            else:
                html_lines.append('<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>')
                continue
        else:
            if in_table:
                html_lines.append('</tbody></table></div>')
                in_table = False
                
        # Empty lines
        if not stripped:
            html_lines.append('')
            continue
            
        # Headings
        if stripped.startswith('# '):
            html_lines.append(f'<h1 class="chapter-title">{stripped[2:].strip()}</h1>')
            continue
        if stripped.startswith('## '):
            html_lines.append(f'<h2>{stripped[3:].strip()}</h2>')
            continue
        if stripped.startswith('### '):
            html_lines.append(f'<h3>{stripped[4:].strip()}</h3>')
            continue
        if stripped.startswith('#### '):
            html_lines.append(f'<h4>{stripped[5:].strip()}</h4>')
            continue
            
        # Unordered lists
        if stripped.startswith('- ') or stripped.startswith('* '):
            content = stripped[2:].strip()
            html_lines.append(f'<ul><li>{content}</li></ul>')
            continue
            
        # Ordered lists
        match_ol = re.match(r'^(\d+)\.\s+(.*)$', stripped)
        if match_ol:
            html_lines.append(f'<ol start="{match_ol.group(1)}"><li>{match_ol.group(2)}</li></ol>')
            continue
            
        # Blockquotes
        if stripped.startswith('> '):
            html_lines.append(f'<blockquote>{stripped[2:].strip()}</blockquote>')
            continue
            
        # Horizontal rules
        if stripped in ('---', '***', '___'):
            html_lines.append('<hr class="academic-divider">')
            continue
            
        # Paragraphs
        html_lines.append(f'<p>{line}</p>')
        
    if in_table:
        html_lines.append('</tbody></table></div>')
        
    body_content = '\n'.join(html_lines)
    
    # Inline formatting (bold, italic, code, math)
    body_content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', body_content)
    body_content = re.sub(r'\*(.*?)\*', r'<em>\1</em>', body_content)
    body_content = re.sub(r'`([^`]+)`', r'<code>\1</code>', body_content)
    
    # Clean redundant ul/ol wrappers
    body_content = body_content.replace('</ul>\n<ul>', '')
    body_content = body_content.replace('</ol>\n<ol>', '')

    html_document = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Design, Implementation, and Cryptanalytic Evaluation of an Interactive Vigenère Cipher Educational Platform</title>
    <style>
        @page {{
            size: A4 portrait;
            margin: 25mm 20mm 25mm 25mm;
            @top-center {{
                content: "B.Tech Project Report: Interactive Vigenère Cipher Educational Platform";
                font-family: 'Times New Roman', serif;
                font-size: 9pt;
                color: #555;
                border-bottom: 0.5pt solid #bbb;
                padding-bottom: 4px;
            }}
            @bottom-right {{
                content: "Page " counter(page);
                font-family: 'Times New Roman', serif;
                font-size: 10pt;
                color: #333;
            }}
        }}

        body {{
            font-family: 'Times New Roman', Times, 'Georgia', serif;
            font-size: 12pt;
            line-height: 1.6;
            color: #111;
            background: #fff;
            margin: 0 auto;
            max-width: 850px;
            padding: 40px 20px;
            text-rendering: optimizeLegibility;
        }}

        h1, h2, h3, h4, h5 {{
            font-family: 'Times New Roman', Times, 'Georgia', serif;
            color: #0b1d3a;
            font-weight: bold;
            page-break-after: avoid;
        }}

        h1.chapter-title {{
            font-size: 22pt;
            border-bottom: 2pt solid #0b1d3a;
            padding-bottom: 8px;
            margin-top: 30px;
            margin-bottom: 25px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        h2 {{
            font-size: 15pt;
            margin-top: 28px;
            margin-bottom: 12px;
            border-bottom: 1pt solid #ddd;
            padding-bottom: 4px;
        }}

        h3 {{
            font-size: 13pt;
            margin-top: 20px;
            margin-bottom: 8px;
        }}

        h4 {{
            font-size: 12pt;
            font-style: italic;
            margin-top: 16px;
            margin-bottom: 6px;
        }}

        p {{
            text-align: justify;
            text-justify: inter-word;
            margin-bottom: 14px;
            margin-top: 0;
            text-indent: 1.5em;
        }}

        p:first-of-type, .no-indent {{
            text-indent: 0;
        }}

        .page-break {{
            page-break-before: always;
            break-before: page;
            height: 0;
            margin: 0;
            padding: 0;
        }}

        .table-container {{
            width: 100%;
            overflow-x: auto;
            margin: 20px 0;
            page-break-inside: avoid;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 10pt;
            margin-bottom: 15px;
        }}

        th, td {{
            border: 1px solid #444;
            padding: 7px 10px;
            text-align: left;
        }}

        th {{
            background-color: #f0f4f8;
            color: #0b1d3a;
            font-weight: bold;
            text-align: center;
        }}

        tr:nth-child(even) td {{
            background-color: #fafbfc;
        }}

        pre {{
            background-color: #f6f8fa;
            border: 1px solid #d0d7de;
            border-radius: 4px;
            padding: 14px;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 9.5pt;
            line-height: 1.45;
            overflow-x: auto;
            margin: 18px 0;
            page-break-inside: avoid;
        }}

        code {{
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 10pt;
            background: #f1f3f5;
            padding: 2px 5px;
            border-radius: 3px;
        }}

        pre code {{
            background: transparent;
            padding: 0;
        }}

        blockquote {{
            border-left: 4px solid #00d4aa;
            margin: 16px 0;
            padding: 10px 20px;
            background-color: #f8fafc;
            font-style: italic;
            color: #334155;
            page-break-inside: avoid;
        }}

        ul, ol {{
            margin-top: 0;
            margin-bottom: 14px;
            padding-left: 30px;
        }}

        li {{
            margin-bottom: 5px;
            text-align: justify;
        }}

        .academic-divider {{
            border: 0;
            height: 1px;
            background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0));
            margin: 25px 0;
        }}

        /* Print Specific Optimization */
        @media print {{
            body {{
                max-width: 100%;
                padding: 0;
                font-size: 11pt;
            }}
            .table-container {{
                overflow: visible;
            }}
            pre {{
                white-space: pre-wrap;
                word-break: break-all;
            }}
        }}
    </style>
</head>
<body>
{body_content}
</body>
</html>"""
    return html_document

def main():
    print("[*] Assembling 70-Page B.Tech Project Report...")
    
    # 1. Combine Markdown components
    full_markdown = (
        FRONT_MATTER.strip() + "\n\n" +
        CHAPTERS_4_TO_6.strip() + "\n\n" +
        CHAPTERS_7_TO_9.strip() + "\n\n" +
        CHAPTERS_10_TO_END.strip() + "\n"
    )
    
    # Paths
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    docs_dir = os.path.join(base_dir, "docs")
    os.makedirs(docs_dir, exist_ok=True)
    
    md_output_path = os.path.join(docs_dir, "PROJECT_REPORT_70_PAGES.md")
    html_output_path = os.path.join(docs_dir, "PROJECT_REPORT_70_PAGES.html")
    
    # 2. Save complete Markdown file
    with open(md_output_path, "w", encoding="utf-8") as f:
        f.write(full_markdown)
    print(f"[+] Successfully generated Markdown thesis at: {md_output_path}")
    
    # 3. Convert to formatted Academic HTML
    print("[*] Generating print-optimized academic HTML document...")
    full_html = convert_markdown_to_academic_html(full_markdown)
    with open(html_output_path, "w", encoding="utf-8") as f:
        f.write(full_html)
    print(f"[+] Successfully generated Printable HTML thesis at: {html_output_path}")
    
    # 4. Statistical Metrics & Page Count Estimation
    word_count = len(re.findall(r'\b\w+\b', full_markdown))
    char_count = len(full_markdown)
    line_count = len(full_markdown.splitlines())
    explicit_page_breaks = full_markdown.count('<div style="page-break-after: always;"></div>')
    
    # Standard academic thesis metrics:
    # 1 A4 page ~ 320-380 words (1.5 line spacing, 12pt Times New Roman, 1-inch margins)
    # Plus tables (each takes 0.5 to 1 full page), code blocks, diagrams, and section breaks
    raw_text_pages = word_count / 350.0
    table_count = full_markdown.count('| :---') + full_markdown.count('|:---')
    code_block_count = full_markdown.count('```') // 2
    
    # Formula for estimated formatted academic pages:
    estimated_pages = max(
        explicit_page_breaks + 5,
        int(raw_text_pages + (table_count * 0.75) + (code_block_count * 0.5) + (explicit_page_breaks * 0.5))
    )
    
    print("\n" + "="*60)
    print("      ACADEMIC PROJECT REPORT GENERATION METRICS")
    print("="*60)
    print(f" Total Word Count       : {word_count:,} words")
    print(f" Total Character Count  : {char_count:,} characters")
    print(f" Total Markdown Lines   : {line_count:,} lines")
    print(f" Formatted Tables       : {table_count} tables")
    print(f" Annotated Code Blocks  : {code_block_count} code blocks")
    print(f" Explicit Section Breaks: {explicit_page_breaks} breaks")
    print(f" ESTIMATED PRINT PAGES  : ~{estimated_pages} Pages (A4 Standard Format)")
    print("="*60 + "\n")

if __name__ == '__main__':
    main()
