# scripts/generate_docx.py
import os
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_header_footer(doc):
    for s in doc.sections:
        s.top_margin = Inches(1.0)
        s.bottom_margin = Inches(1.0)
        s.left_margin = Inches(1.0)
        s.right_margin = Inches(1.0)
        
        # Header
        header = s.header
        p_hdr = header.paragraphs[0]
        p_hdr.text = "B.Tech Major Project Report: Interactive Vigenère Cipher Platform"
        p_hdr.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_hdr.style.font.name = "Times New Roman"
        p_hdr.style.font.size = Pt(8.5)
        p_hdr.style.font.color.rgb = RGBColor(100, 100, 100)
        
        # Footer
        footer = s.footer
        p_ftr = footer.paragraphs[0]
        p_ftr.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_ftr.style.font.name = "Times New Roman"
        p_ftr.style.font.size = Pt(9.5)
        p_ftr.style.font.color.rgb = RGBColor(80, 80, 80)
        # Add Page Number field to footer
        run_ftr = p_ftr.add_run("Page ")
        fldSimple = parse_xml(r'<w:fldSimple %s w:instr="PAGE"/>' % nsdecls('w'))
        p_ftr._p.append(fldSimple)

def sanitize_xml_string(text):
    if not text:
        return ""
    # Remove control characters that are invalid in XML 1.0
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x84\x86-\x9f]', '', str(text))

def apply_text_formatting(paragraph, text):
    """
    Parses bold (**text**), italic (*text*), and code (`text`) inside text
    and applies corresponding Word runs.
    """
    text = sanitize_xml_string(text)
    tokens = re.split(r'(\*\*.*?\*\*|\*.*?\*|`.*?`)', text)
    for token in tokens:
        if not token:
            continue
        token_clean = sanitize_xml_string(token)
        if token.startswith('**') and token.endswith('**') and len(token) >= 4:
            r = paragraph.add_run(sanitize_xml_string(token[2:-2]))
            r.bold = True
        elif token.startswith('*') and token.endswith('*') and len(token) >= 2:
            r = paragraph.add_run(sanitize_xml_string(token[1:-1]))
            r.italic = True
        elif token.startswith('`') and token.endswith('`') and len(token) >= 2:
            r = paragraph.add_run(sanitize_xml_string(token[1:-1]))
            r.font.name = 'Consolas'
            r.font.size = Pt(10)
            r.font.color.rgb = RGBColor(30, 41, 59)
        else:
            paragraph.add_run(token_clean)

def build_docx_from_markdown(md_file_path, docx_output_path):
    print(f"[*] Reading markdown file: {md_file_path}")
    with open(md_file_path, 'r', encoding='utf-8') as f:
        md_text = f.read()

    doc = Document()
    add_header_footer(doc)
    
    # Configure Normal Style
    normal_style = doc.styles['Normal']
    normal_style.font.name = 'Times New Roman'
    normal_style.font.size = Pt(12)
    normal_style.font.color.rgb = RGBColor(17, 24, 39)
    normal_style.paragraph_format.line_spacing = 1.35
    normal_style.paragraph_format.space_after = Pt(6)

    lines = md_text.splitlines()
    in_code = False
    code_lines = []
    in_table = False
    table_rows = []

    print("[*] Parsing content and writing formatted elements into Word...")
    
    for line in lines:
        stripped = line.strip()

        # Handle explicit page break marker
        if '<div style="page-break-after: always;"></div>' in line:
            if in_table and table_rows:
                create_word_table(doc, table_rows)
                in_table = False
                table_rows = []
            doc.add_page_break()
            continue

        # Code block handler
        if stripped.startswith('```'):
            if not in_code:
                if in_table and table_rows:
                    create_word_table(doc, table_rows)
                    in_table = False
                    table_rows = []
                in_code = True
                code_lines = []
            else:
                in_code = False
                code_text = sanitize_xml_string("\n".join(code_lines))
                p_code = doc.add_paragraph()
                p_code.paragraph_format.line_spacing = 1.05
                p_code.paragraph_format.space_before = Pt(6)
                p_code.paragraph_format.space_after = Pt(8)
                p_code.paragraph_format.left_indent = Inches(0.2)
                r_code = p_code.add_run(code_text)
                r_code.font.name = 'Consolas'
                r_code.font.size = Pt(9.5)
                r_code.font.color.rgb = RGBColor(15, 23, 42)
                code_lines = []
            continue

        if in_code:
            code_lines.append(line)
            continue

        # Table rows handler
        if stripped.startswith('|') and stripped.endswith('|'):
            cells = [sanitize_xml_string(c.strip()) for c in stripped[1:-1].split('|')]
            # Check if this is a separator row like |:---|:---|
            if all(re.match(r'^:?-+:?$', c) for c in cells):
                continue
            table_rows.append(cells)
            in_table = True
            continue
        else:
            if in_table and table_rows:
                create_word_table(doc, table_rows)
                in_table = False
                table_rows = []

        # Empty lines
        if not stripped:
            continue

        # Headings
        if stripped.startswith('# '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(18)
            p.paragraph_format.space_after = Pt(10)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(sanitize_xml_string(stripped[2:].strip()))
            r.bold = True
            r.font.name = 'Times New Roman'
            r.font.size = Pt(20)
            r.font.color.rgb = RGBColor(11, 29, 58)
            continue

        if stripped.startswith('## '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(sanitize_xml_string(stripped[3:].strip()))
            r.bold = True
            r.font.name = 'Times New Roman'
            r.font.size = Pt(15)
            r.font.color.rgb = RGBColor(11, 29, 58)
            continue

        if stripped.startswith('### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(sanitize_xml_string(stripped[4:].strip()))
            r.bold = True
            r.font.name = 'Times New Roman'
            r.font.size = Pt(13)
            r.font.color.rgb = RGBColor(30, 41, 59)
            continue

        if stripped.startswith('#### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.keep_with_next = True
            r = p.add_run(sanitize_xml_string(stripped[5:].strip()))
            r.bold = True
            r.italic = True
            r.font.name = 'Times New Roman'
            r.font.size = Pt(12)
            continue

        # Bullet List
        if stripped.startswith('- ') or stripped.startswith('* '):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.line_spacing = 1.25
            p.paragraph_format.space_after = Pt(3)
            apply_text_formatting(p, stripped[2:].strip())
            continue

        # Numbered List
        match_ol = re.match(r'^(\d+)\.\s+(.*)$', stripped)
        if match_ol:
            p = doc.add_paragraph(style='List Number')
            p.paragraph_format.line_spacing = 1.25
            p.paragraph_format.space_after = Pt(3)
            apply_text_formatting(p, match_ol.group(2).strip())
            continue

        # Blockquote
        if stripped.startswith('> '):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.4)
            p.paragraph_format.right_indent = Inches(0.2)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(6)
            apply_text_formatting(p, stripped[2:].strip())
            for r in p.runs:
                r.italic = True
                r.font.color.rgb = RGBColor(51, 65, 85)
            continue

        # Horizontal Rule
        if stripped in ('---', '***', '___'):
            continue

        # HTML formatting tags (like centered title page)
        clean_line = re.sub(r'<[^>]+>', '', line).strip()
        if not clean_line:
            continue

        # Standard Paragraph
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        apply_text_formatting(p, clean_line)

    # Clean up lingering tables
    if in_table and table_rows:
        create_word_table(doc, table_rows)

    print(f"[*] Saving Word document to: {docx_output_path}")
    doc.save(docx_output_path)
    print(f"[+] Word document successfully generated! File size: {os.path.getsize(docx_output_path) / (1024*1024):.2f} MB")

def create_word_table(doc, rows_data):
    if not rows_data:
        return
    num_rows = len(rows_data)
    num_cols = max(len(row) for row in rows_data)
    
    # Pad rows to have uniform column lengths
    for r in rows_data:
        while len(r) < num_cols:
            r.append("")
            
    table = doc.add_table(rows=num_rows, cols=num_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # Style header row
    header_cells = table.rows[0].cells
    for i, title in enumerate(rows_data[0]):
        clean_title = sanitize_xml_string(title)
        header_cells[i].text = clean_title
        set_cell_background(header_cells[i], "E2E8F0")
        set_cell_margins(header_cells[i], top=100, bottom=100, left=120, right=120)
        p = header_cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:
            r.bold = True
            r.font.size = Pt(9.5)
            r.font.name = "Times New Roman"
            r.font.color.rgb = RGBColor(11, 29, 58)

    # Style data rows
    for r_idx in range(1, num_rows):
        row_cells = table.rows[r_idx].cells
        bg_color = "F8FAFC" if (r_idx % 2 == 1) else "FFFFFF"
        for c_idx in range(num_cols):
            cell_text = sanitize_xml_string(rows_data[r_idx][c_idx])
            row_cells[c_idx].text = cell_text
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], top=80, bottom=80, left=100, right=100)
            p = row_cells[c_idx].paragraphs[0]
            p.paragraph_format.line_spacing = 1.05
            p.paragraph_format.space_after = Pt(1)
            for r in p.runs:
                r.font.size = Pt(9)
                r.font.name = "Times New Roman"

    # Add space after table
    p_spacer = doc.add_paragraph()
    p_spacer.paragraph_format.space_after = Pt(6)

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    md_path = os.path.join(base_dir, "docs", "PROJECT_REPORT_70_PAGES.md")
    
    # Generate both in docs and in root for quick access
    docx_docs_path = os.path.join(base_dir, "docs", "PROJECT_REPORT_VIGENERE_CIPHER.docx")
    docx_root_path = os.path.join(base_dir, "VIGENERE_CIPHER_70_PAGES_PROJECT_REPORT.docx")
    
    build_docx_from_markdown(md_path, docx_docs_path)
    
    import shutil
    shutil.copyfile(docx_docs_path, docx_root_path)
    print(f"[+] Copied Word document to root: {docx_root_path}")
