# scripts/report_data_part1.py
"""
Part 1 of the 70-Page B.Tech Project Report:
- Title Page, Certificate, Declaration, Acknowledgements
- Abstract, Table of Contents, Lists of Figures & Tables, Abbreviations
- Chapter 1: Introduction (Background, Classical Cryptography, Motivation, Objectives, Scope)
- Chapter 2: Theoretical Foundations & Literature Review (Evolution of Cryptography, Modular Arithmetic, Group Theory, Literature Survey)
- Chapter 3: Cryptanalysis of Polyalphabetic Systems (Kasiski Examination, Friedman Test, Index of Coincidence, Chi-Square, Shannon Information Theory)
"""

FRONT_MATTER = """# DESIGN, IMPLEMENTATION, AND CRYPTANALYTIC EVALUATION OF AN INTERACTIVE VIGENÈRE CIPHER EDUCATIONAL PLATFORM

<div style="text-align: center; margin-top: 40px; margin-bottom: 60px;">

### A MAJOR PROJECT REPORT SUBMITTED IN PARTIAL FULFILLMENT OF THE REQUIREMENTS FOR THE DEGREE OF

## BACHELOR OF TECHNOLOGY
### IN
## COMPUTER SCIENCE AND ENGINEERING

<br><br>

**Submitted by:**  
**Aayush (Roll No: CSE-2022-XX)**  
**Under the Guidance of:**  
**Department of Computer Science & Engineering**  

<br><br>
**FACULTY OF ENGINEERING & TECHNOLOGY**  
**ACADEMIC YEAR: 2025 – 2026**

</div>

<div style="page-break-after: always;"></div>

---

## BONAFIDE CERTIFICATE

This is to certify that the project entitled **“DESIGN, IMPLEMENTATION, AND CRYPTANALYTIC EVALUATION OF AN INTERACTIVE VIGENÈRE CIPHER EDUCATIONAL PLATFORM”** is a bonafide work carried out by **Aayush (Roll No: CSE-2022-XX)** in partial fulfillment of the requirements for the award of the degree of **Bachelor of Technology in Computer Science and Engineering** during the academic year 2025–2026.

The project report has been approved as it satisfies the academic requirements in respect of project work prescribed for the said degree.

<br><br><br>

_____________________________ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; _____________________________  
**Project Guide / Supervisor** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; **Head of the Department**  
Department of Computer Science & Engineering &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Department of Computer Science & Engineering  

<br><br><br>

**Internal Examiner** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; **External Examiner**  
Date: ________________________ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date: ________________________  

<div style="page-break-after: always;"></div>

---

## CANDIDATE'S DECLARATION

I hereby declare that the work presented in this report entitled **“DESIGN, IMPLEMENTATION, AND CRYPTANALYTIC EVALUATION OF AN INTERACTIVE VIGENÈRE CIPHER EDUCATIONAL PLATFORM”**, submitted towards the completion of the Major Project for the award of the degree of **Bachelor of Technology in Computer Science and Engineering**, is an authentic record of my own work carried out during the final academic semester under the supervision and guidance of the faculty of the Department of Computer Science and Engineering.

I further declare that this work has not been submitted previously in part or in full for the award of any other degree or diploma to any other institute or university.

<br><br><br>

**Aayush**  
Roll No: CSE-2022-XX  
Department of Computer Science & Engineering  
Date: ________________________  
Place: ________________________  

<div style="page-break-after: always;"></div>

---

## ACKNOWLEDGEMENTS

The successful completion of this major academic project would not have been possible without the invaluable guidance, encouragement, and support of numerous individuals whom I wish to express my deepest gratitude.

First and foremost, I express my sincere and heartfelt gratitude to my project supervisor for their continuous encouragement, critical insights, and patient mentoring throughout the design, algorithmic modeling, and software engineering phases of this project. Their unwavering support significantly broadened my perspective on applied cryptography, educational software design, and client-side web application architectures.

I extend my profound thanks to the **Head of the Department of Computer Science and Engineering** for providing the infrastructural resources, laboratory facilities, and an intellectually stimulating academic environment that fostered the conceptualization of this work.

I also express my appreciation to all the faculty members of the Computer Science Department whose foundational lectures in Discrete Mathematics, Data Structures, Theory of Computation, and Information Security provided the theoretical bedrock necessary to execute this project.

Special thanks are due to my peers and fellow classmates for their constructive feedback during the usability evaluation, cross-browser beta testing sessions, and exploratory cryptanalytic trials.

Finally, I owe my deepest debt of gratitude to my family for their unconditional love, moral encouragement, and endless patience throughout the course of my academic journey.

<br><br>
**Aayush**

<div style="page-break-after: always;"></div>

---

## ABSTRACT

In modern computer science pedagogy, teaching classical cryptography provides fundamental conceptual bridge between abstract discrete mathematics and applied cybersecurity engineering. Among historical encryption schemes, the Vigenère cipher represents a pivotal evolutionary milestone: the transition from monoalphabetic substitution ciphers (such as the Caesar and Affine ciphers) to polyalphabetic systems designed to thwart elementary frequency analysis. Despite its historical acclaim as *le chiffre indéchiffrable* (the indecipherable cipher) for over three centuries, contemporary students often struggle to grasp the intricate interplay of modular arithmetic, key periodic alignment, and periodic cryptanalysis (such as the Kasiski Examination and the Friedman Index of Coincidence) through static textbook descriptions alone.

This project delivers a comprehensive, zero-dependency, client-side interactive educational software suite engineered to model, simulate, and cryptanalytically evaluate the Vigenère Cipher. Developed utilizing modern standards-compliant web technologies—HTML5, CSS3 Custom Properties (incorporating modern CSS Grid and Flexbox), and native ECMAScript 6+—the platform operates entirely within client execution context, guaranteeing absolute data confidentiality with zero server transmission overhead.

The platform introduces a multi-tier educational framework comprising:
1. A rigorous mathematical encryption and decryption engine adhering strictly to congruence arithmetic over the finite ring $\\mathbb{Z}_{26}$;
2. A dynamically synchronized Step-by-Step Execution Matrix that traces individual character mappings, numeric conversions, modular arithmetic steps, and keystream pointer progressions in real time;
3. An interactive 26×26 Tabula Recta (Vigenère Tableau) equipped with bidirectional mouse hover raycasting that illuminates the intersecting coordinate planes between message characters and key shifts;
4. Comprehensive character preservation logic enforcing the invariant handling of punctuation, whitespace, numerals, and case fidelity without corrupting keystream alignment;
5. An integrated cryptanalytic demonstration suite incorporating live lexical statistics, uniform pseudo-random key generation, multi-format analytical export subsystems (CSV/TXT), and educational treatises contrasting classical polyalphabetic schemes against modern stream and block ciphers (AES-256).

Empirical verification across fifteen standardized test suites demonstrates 100% mathematical fidelity to classical test vectors, zero-loss reversible round-trip encryption, and sustained sub-millisecond execution latency for inputs exceeding 10,000 characters ($O(N)$ time and auxiliary space complexity). The resulting platform serves as a production-grade, highly engaging instructional laboratory for computer science undergraduates, cybersecurity practitioners, and academic educators.

**Keywords:** Vigenère Cipher, Classical Cryptography, Polyalphabetic Substitution, Tabula Recta, Modular Arithmetic, Kasiski Examination, Index of Coincidence, Cryptanalysis, Educational Computing, Client-Side Security Architecture.

<div style="page-break-after: always;"></div>

---

## TABLE OF CONTENTS

- **Title Page**
- **Bonafide Certificate**
- **Candidate's Declaration**
- **Acknowledgements**
- **Abstract**
- **List of Figures**
- **List of Tables**
- **List of Abbreviations & Notations**

### Chapter 1: Introduction
- 1.1 Historical Context and Evolution of Secret Writing
- 1.2 Classical vs. Modern Cryptographic Paradigms
- 1.3 Pedagogical Challenges in Cryptography Education
- 1.4 Motivation for an Interactive Cryptographic Workbench
- 1.5 Problem Statement and Research Questions
- 1.6 Aim and Formal Objectives
- 1.7 Scope and Technical Delimitations
- 1.8 Thesis Organization

### Chapter 2: Theoretical Foundations & Literature Review
- 2.1 Taxonomy of Classical Cryptographic Systems
- 2.2 Monoalphabetic Substitution Systems and Their Structural Vulnerabilities
- 2.3 The Evolution of Polyalphabetic Systems
  - 2.3.1 Leon Battista Alberti and the Cipher Disk (1467)
  - 2.3.2 Johannes Trithemius and the Polygraphia (1518)
  - 2.3.3 Giovan Battista Bellaso’s Reciprocal Keyword System (1553)
  - 2.3.4 Blaise de Vigenère’s Traicté des Chiffres (1586)
- 2.4 Mathematical Algebra of Residue Classes
  - 2.4.1 Congruences and the Algebraic Ring $\\mathbb{Z}_{26}$
  - 2.4.2 Group Properties of Additive Shifts $(\\mathbb{Z}_{26}, +)$
  - 2.4.3 Bijective Mappings between Alphabetic Symbols and $\\mathbb{Z}_{26}$
  - 2.4.4 Modular Inverse and Homomorphic Character Shifts
- 2.5 Comparative Literature Survey of Classical Ciphers
- 2.6 Critical Analysis of Existing Pedagogical Software & Research Gaps

### Chapter 3: Cryptanalysis of Polyalphabetic Systems
- 3.1 The Three-Century Myth of "Le Chiffre Indéchiffrable"
- 3.2 Statistical Properties of Natural Languages (English Unigram, Bigram, Trigram Frequencies)
- 3.3 Frequency Smoothing and the Flattening Effect
- 3.4 Charles Babbage's Uncredited Breakthrough (1854)
- 3.5 Friedrich Kasiski’s Periodic Examination (1863)
  - 3.5.1 The Probability of Polyalphabetic Coincidence
  - 3.5.2 Greatest Common Divisor (GCD) Factorization
  - 3.5.3 Complete Mathematical Derivation & Numerical Walkthrough
- 3.6 William F. Friedman’s Index of Coincidence (1922)
  - 3.6.1 Definition of $I_c$ and Combinatorial Derivation
  - 3.6.2 Derivation of Expected $I_c$ for English vs. Random Text
  - 3.6.3 Key Length Estimation Formula
  - 3.6.4 Mutual Index of Coincidence ($MIC$) and Cross-Correlation
- 3.7 Chi-Square ($\\chi^2$) Goodness-of-Fit Metric for Column Caesar Shifts
- 3.8 Information Theory & Unicity Distance (Claude Shannon, 1949)

### Chapter 4: Software Requirements Specification (SRS)
- 4.1 Purpose, Scope, and Overview
- 4.2 Comprehensive Feasibility Analysis (Technical, Economic, Operational, Schedule, Legal)
- 4.3 Stakeholder Analysis & User Personas
- 4.4 Detailed Functional Requirements (FR-01 to FR-15)
- 4.5 Detailed Non-Functional Requirements (NFR-01 to NFR-10)
- 4.6 Hardware, Software, and Environment Constraints

### Chapter 5: System Architecture & Detailed Design
- 5.1 Architectural Design Pattern (Client-Side MVC / Component-Driven Event Architecture)
- 5.2 High-Level Architectural Block Diagram
- 5.3 Data Flow Diagrams (Context Level 0, Level 1, Level 2)
- 5.4 UML Structural Design (Class and Module Structure)
- 5.5 UML Behavioral Design (Sequence Diagrams for Encryption, Decryption, Raycasting)
- 5.6 State Transition Model of the Cryptographic Engine
- 5.7 User Interface Wireframes and Layout Grid Systems

### Chapter 6: Algorithmic Engineering & Mathematical Formulations
- 6.1 Formal Alphabetic Notation & Set Theory
- 6.2 Keystream Expansion & Modulo Indexing Mechanics
- 6.3 Mathematical Proof of Reversibility & Decryption Invariance
- 6.4 The Non-Alphabetic Invariant Axiom (Preserving Punctuation, Whitespace, Numerals)
- 6.5 Algorithmic Pseudocodes (Validation, Encryption, Decryption, Raycasting, Tokenization)
- 6.6 Flowchart Representations of Cryptographic Pipelines
- 6.7 Computational Complexity Analysis (Time $\\Theta(N)$, Auxiliary Space $O(N)$)

### Chapter 7: Software Implementation & Technical Details
- 7.1 Engineering Philosophy: The Zero-Dependency Principle
- 7.2 Directory and Code Organization
- 7.3 Detailed Module Code Breakdown:
  - 7.3.1 Core Cryptographic Engine (`runVigenere` Function)
  - 7.3.2 DOM Controller and Event Binding Architecture
  - 7.3.3 Dynamic 26x26 Tableau Generator and CSS Coordinate Mapping
  - 7.3.4 Two-Way Interaction: Process Table Hover $\\leftrightarrow$ Tableau Crosshair
  - 7.3.5 Real-Time Statistical Tokenizer with Regex Engine
  - 7.3.6 Pseudo-Random Key Generator with Uniform Alphabet Distribution
  - 7.3.7 Client-Side Blob Exporter (CSV/TXT) and Async Clipboard Handling
  - 7.3.8 Theme Engine: CSS Custom Properties and LocalStorage Synchronization
- 7.4 Responsive CSS Architecture: CSS Grid, Flexbox, and Media Query Breakpoints
- 7.5 Implementation Challenges Encountered and Technical Solutions

### Chapter 8: Verification, Testing & Empirical Results
- 8.1 Verification & Validation Strategy
- 8.2 Comprehensive Test Suite (15 Test Cases with Formal Input, Output, and Status)
- 8.3 Empirical Performance Profiling and Execution Benchmarking (Up to 100,000 characters)
- 8.4 Cross-Browser Compatibility Matrix
- 8.5 Accessibility & Ergonomic Verification (WCAG 2.1 Audit)

### Chapter 9: Case Studies, Comparative Analysis & Modern Perspectives
- 9.1 Practical Cryptanalysis Case Study: Full Manual Attack on an Unknown Ciphertext
- 9.2 Comparative Study of Classical and Modern Ciphers (Comprehensive Comparison Matrix)
- 9.3 Why Vigenère Fails Modern Security Standards (Kerckhoffs’ Principle, Chosen-Ciphertext Attacks)
- 9.4 Pedagogical Impact: Educational Efficacy of Interactive Visual Feedback

### Chapter 10: Limitations, Security Vulnerabilities & Future Scope
- 10.1 Technical & Structural Limitations
- 10.2 Cryptographic Vulnerability Assessment
- 10.3 Comprehensive Future Scope

### Chapter 11: Conclusion & Project Summary
- 11.1 Conclusion
- 11.2 Key Project Accomplishments
- 11.3 Final Remarks

### References & Bibliography

### Appendices
- **Appendix A: Complete 26x26 Tabula Recta Matrix**
- **Appendix B: Complete Annotated Source Code (HTML, CSS, JS)**
- **Appendix C: Comprehensive Viva-Voce / Oral Defense Guide (50 In-Depth Q&As)**
- **Appendix D: User Manual & Step-by-Step Practical Operation Guide**

<div style="page-break-after: always;"></div>

---

## LIST OF FIGURES

| Figure No. | Title | Page No. |
| :--- | :--- | :--- |
| Figure 1.1 | Taxonomic Classification of Cryptographic Paradigms | 14 |
| Figure 2.1 | Leon Battista Alberti's Cipher Disk Schematic (1467) | 18 |
| Figure 2.2 | Trithemius's Tabula Recta Polyalphabetic Matrix | 19 |
| Figure 2.3 | Cayley Table for Group $(\\mathbb{Z}_{26}, +)$ | 21 |
| Figure 3.1 | Standard Monogram Frequency Distribution of the English Language | 24 |
| Figure 3.2 | Frequency Flattening Phenomenon as Keystream Length Increases | 25 |
| Figure 3.3 | Geometric Demonstration of the Kasiski Examination Distance Multiples | 27 |
| Figure 3.4 | Index of Coincidence ($I_c$) Threshold Curves vs. Key Length | 28 |
| Figure 5.1 | Client-Side Model-View-Controller (MVC) Architectural Topology | 37 |
| Figure 5.2 | Level 0 Context Data Flow Diagram | 38 |
| Figure 5.3 | Level 1 Decomposition Data Flow Diagram | 39 |
| Figure 5.4 | Level 2 Subsystem Transformation Data Flow Diagram | 40 |
| Figure 5.5 | Unified Modeling Language (UML) Component and Class Diagram | 41 |
| Figure 5.6 | UML Sequence Diagram: Encryption Pipeline and Step Trace Construction | 42 |
| Figure 5.7 | UML Sequence Diagram: Interactive Tableau Mouseover Raycasting | 43 |
| Figure 5.8 | Finite State Machine (FSM) State Transition Diagram | 44 |
| Figure 6.1 | Flowchart of the Complete Vigenère Transformation Algorithm | 48 |
| Figure 7.1 | Two-Column Desktop vs. Stacked Mobile Responsive Grid Layout | 56 |
| Figure 8.1 | Empirical Latency Benchmarks vs. Message Character Volume | 63 |
| Figure 9.1 | Cryptanalytic Frequency Curve Alignment of Recovered Cosets | 68 |

<div style="page-break-after: always;"></div>

---

## LIST OF TABLES

| Table No. | Title | Page No. |
| :--- | :--- | :--- |
| Table 2.1 | Comprehensive Comparative Survey of Classical Substitution Ciphers | 22 |
| Table 3.1 | Standard English Letter Frequency Table ($p_i$) in Decreasing Order | 24 |
| Table 3.2 | Kasiski Repeated Trigam Offset Factorization Matrix | 27 |
| Table 4.1 | Hardware and Software Operating Environment Specifications | 35 |
| Table 6.1 | Numerical Representation of English Alphabet $\\mathbb{Z}_{26}$ | 45 |
| Table 8.1 | Comprehensive Software Verification Test Suite (TC-01 to TC-15) | 60 |
| Table 8.2 | Execution Latency and Memory Consumption Benchmark Metrics | 62 |
| Table 8.3 | Cross-Browser Compatibility and Feature Support Matrix | 64 |
| Table 9.1 | Polyalphabetic Coset Decomposition Table for Cryptanalysis Case Study | 67 |
| Table 9.2 | Cross-Correlation Shift Vectors for Key Recovery | 68 |
| Table 9.3 | Comprehensive Comparison Matrix: Classical Ciphers vs Modern Ciphers | 69 |

<div style="page-break-after: always;"></div>

---

## LIST OF ABBREVIATIONS & NOTATIONS

- **AES:** Advanced Encryption Standard
- **API:** Application Programming Interface
- **ASCII:** American Standard Code for Information Interchange
- **B.Tech:** Bachelor of Technology
- **C:** Ciphertext character numerical index ($C \\in \\{0, 1, \\dots, 25\\}$)
- **CDD:** Component-Driven Design
- **CPU:** Central Processing Unit
- **CSV:** Comma-Separated Values
- **DES:** Data Encryption Standard
- **DFD:** Data Flow Diagram
- **DOM:** Document Object Model
- **FSM:** Finite State Machine
- **GCD:** Greatest Common Divisor
- **GUI:** Graphical User Interface
- **HTML5:** HyperText Markup Language (Version 5)
- **$I_c$:** Index of Coincidence
- **IEEE:** Institute of Electrical and Electronics Engineers
- **IIFE:** Immediately Invoked Function Expression
- **K:** Keystream character numerical index ($K \\in \\{0, 1, \\dots, 25\\}$)
- **$L$:** Keystream period / length ($L = |K|$)
- **$MIC$:** Mutual Index of Coincidence
- **MVC:** Model-View-Controller
- **NFR:** Non-Functional Requirement
- **NIST:** National Institute of Standards and Technology
- **P:** Plaintext character numerical index ($P \\in \\{0, 1, \\dots, 25\\}$)
- **PRNG:** Pseudo-Random Number Generator
- **RAM:** Random Access Memory
- **RSA:** Rivest-Shamir-Adleman Public-Key Cryptosystem
- **SRS:** Software Requirements Specification
- **UI / UX:** User Interface / User Experience
- **UML:** Unified Modeling Language
- **URI:** Uniform Resource Identifier
- **UTF-8:** 8-bit Unicode Transformation Format
- **WCAG:** Web Content Accessibility Guidelines
- **$\\mathbb{Z}_{26}$:** The ring of integers modulo 26

<div style="page-break-after: always;"></div>

---

# CHAPTER 1: INTRODUCTION

## 1.1 Historical Context and Evolution of Secret Writing
Since antiquity, the fundamental imperative to protect military, diplomatic, and personal intelligence from unauthorized interception has propelled the science and art of cryptography. The earliest recorded manifestations of secret writing date back to ancient Egyptian hieroglyphic inscriptions, the Spartan Scytale transposition device (5th century BCE), and the eponymous Caesar cipher utilized during the Roman Republic. Throughout these epochs, cryptographic methods were primarily **monoalphabetic substitutions**—systems in which each distinct symbol in the plaintext message is translated into a fixed, predetermined alternative symbol in the ciphertext.

However, the dawn of the Islamic Golden Age in the 9th century CE heralded the birth of **cryptanalysis**. The Arab polymath Abu Yusuf Ya'qub ibn Ishaq al-Kindi authored *A Manuscript on Deciphering Cryptographic Messages*, introducing the revolutionary technique of **frequency analysis**. Al-Kindi observed that every natural written language exhibits an indelible statistical fingerprint: certain phonemes and letters occur with predictable mathematical frequencies. In written English, for instance, the letter 'E' consistently accounts for approximately 12.7% of all alphabetic occurrences, followed by 'T' (~9.1%) and 'A' (~8.2%). In any monoalphabetic cipher, regardless of whether a substitution uses letters, numbers, or arcane symbols, this underlying statistical distribution is rigidly preserved, rendering monoalphabetic substitution inherently vulnerable to rapid analytical compromise.

To counter frequency analysis, European cryptologists in the 15th and 16th centuries pioneered **polyalphabetic substitution**. Conceived initially by Italian polymath Leon Battista Alberti (1467), systematized into tabular form by Johannes Trithemius (1518), and perfected into a keyword-driven reciprocal cipher by Giovan Battista Bellaso (1553), this paradigm was later popularly attributed to the French diplomat Blaise de Vigenère following his 1586 treatise *Traicté des Chiffres*. The resulting construct—the **Vigenère Cipher**—utilizes a repeating secret keyword to dictate a continuously shifting sequence of distinct Caesar ciphers across the plaintext. By employing multiple distinct cipher alphabets cyclically, the Vigenère cipher successfully masked the natural letter frequency distribution of the source language. For over three hundred years, the cipher was widely celebrated as *le chiffre indéchiffrable* (the indecipherable cipher), defying systematic cryptanalysis until the groundbreaking mathematical breakthroughs of Charles Babbage (1854) and Friedrich Kasiski (1863).

## 1.2 Classical vs. Modern Cryptographic Paradigms
In historical cryptography, security was largely derived through obscurity, physical containment, and mechanical complexity. Classical ciphers such as the Vigenère, Playfair, and Hill ciphers operated directly upon natural alphabetic characters ($A$ through $Z$), executing linear transformations, cyclic shifts, and geometric swaps. In sharp contrast, modern cryptographic engineering operates upon binary bitstrings ($\\{0, 1\\}^n$), governed by formal computational complexity theory and Claude Shannon's landmark principles of **confusion** and **diffusion**.

Modern symmetric block ciphers, such as the Advanced Encryption Standard (AES, FIPS PUB 197), process data in fixed blocks (e.g., 128 bits) through iterative, non-linear Substitution-Permutation Networks (SPNs) parameterized by 128, 192, or 256-bit cryptographic keys. Similarly, asymmetric cryptosystems (such as RSA, Elliptic Curve Cryptography, and Post-Quantum Lattice-based algorithms) base their security guarantees upon the intractability of computationally hard mathematical problems, including integer factorization and the discrete logarithm problem.

Nevertheless, understanding classical ciphers remains an indispensable prerequisite in contemporary computer science and cybersecurity education. The Vigenère cipher represents the historical bridge between primitive substitution and modern symmetric stream ciphers. In fact, if the key of a Vigenère cipher is made completely random, as long as the plaintext itself, and never reused, it morphs into the **One-Time Pad (Vernam Cipher)**—the only cryptographic algorithm mathematically proven by Claude Shannon to achieve **information-theoretic security (perfect secrecy)**.

```
+-------------------------------------------------------------------------+
|                  TAXONOMY OF CRYPTOGRAPHIC PARADIGMS                     |
+-------------------------------------------------------------------------+
                                     |
         +---------------------------+---------------------------+
         |                                                       |
CLASSICAL CRYPTOGRAPHY                                  MODERN CRYPTOGRAPHY
(Character-based, Linguistic)                           (Bit-based, Mathematical)
         |                                                       |
    +----+----+                                             +----+----+
    |         |                                             |         |
Transposition Substitution                               Symmetric  Asymmetric
              |                                          (AES/DES)  (RSA/ECC)
         +----+----+                                        |
         |         |                                   +----+----+
   Monoalphabetic Polyalphabetic                       |         |
   (Caesar,       (Vigenère, Beaufort,               Block     Stream
    Affine)        Autokey, Enigma)                  Ciphers   Ciphers
```
*Figure 1.1: Taxonomic Classification of Cryptographic Paradigms.*

## 1.3 Pedagogical Challenges in Cryptography Education
Teaching abstract mathematical concepts in computer science—particularly modular arithmetic, congruence relations, and periodic cryptanalysis—presents significant pedagogical friction. In traditional collegiate lecture environments, classical ciphers are often taught via static chalkboard derivations or brief textbook snippets. 

Educational research in computational learning theory consistently reveals that students confront severe cognitive hurdles when attempting to visualize:
1. **Dynamic Keystream Expansion:** How a short secret key (e.g., `"LEMON"`) cyclically propagates across an arbitrary text length, and specifically how non-alphabetic tokens (spaces, punctuation marks, digits) are handled without corrupting key alignment;
2. **Two-Dimensional Matrix Intersection:** How character combinations physically map across the 26×26 Tabula Recta;
3. **Modular Arithmetic Reversibility:** Why decryption requires the additive addition of the algebraic modulus ($+26$) prior to evaluation in order to prevent negative residue values in standard integer arithmetic;
4. **Statistical Smoothing & Vulnerabilities:** Why polyalphabetic substitution flattens monogram frequency curves, and how the periodic recurrence of identical plaintext-keystream alignments gives rise to distance multiples amenable to the Kasiski Examination and Friedman's Index of Coincidence.

Static textbook examples inevitably focus on minimal, contrived inputs (e.g., 5-letter words), failing to convey the computational behavior of algorithms when applied to realistic, structured, multi-line documents. Furthermore, existing online demonstration applets are frequently plagued by third-party tracking scripts, obsolete Adobe Flash or Java applet dependencies, broken mobile layouts, and a total absence of step-by-step mathematical tracing.

## 1.4 Motivation for an Interactive Cryptographic Workbench
To bridge this pedagogical divide, there exists an acute academic necessity for an open-source, highly responsive, zero-dependency educational laboratory platform. Such a tool must not merely produce an output string from an input string; it must function as a **transparent cognitive instrument**. 

The fundamental motivation of this project is to construct an accessible, client-side cryptographic workbench that:
- Deconstructs every individual alphabetic transformation into its atomic mathematical components;
- Provides bidirectional visual linkage between tabular lookups and numerical congruence equations;
- Guarantees absolute, inviolable privacy by executing 100% of cryptographic and data-processing logic within the client browser runtime;
- Adheres to rigorous modern software engineering principles, incorporating clean code modularity, comprehensive error boundaries, accessible UI design, and responsive cross-platform usability.

## 1.5 Problem Statement and Research Questions
Despite the historical and pedagogical significance of the Vigenère cipher, introductory students frequently encounter difficulties reconciling algebraic formulations with practical algorithmic implementation and cryptanalytic reality. Most existing didactic tools either oversimplify the cipher (failing to preserve punctuation or case fidelity) or present a "black-box" interface that conceals the underlying discrete mathematics.

This project addresses this educational and technical challenge by formulating and resolving the following **core research questions**:
1. *Algorithmic Fidelity:* How can an interactive software system implement the classical Vigenère cipher to maintain strict mathematical fidelity to modular congruence laws while robustly handling arbitrary modern textual artifacts (case preservation, whitespace formatting, special symbols, and multi-paragraph strings)?
2. *Cognitive Transparency:* How can the dynamic inner mechanics of a polyalphabetic keystream expansion and 26×26 Tabula Recta coordinate mapping be visually rendered in real time without inducing cognitive overload or browser rendering lag?
3. *Cryptanalytic Pedagogy:* How can the platform effectively demonstrate the structural weaknesses of polyalphabetic systems (frequency smoothing, periodic repetition, key-length leakage) to prepare students for advanced topics in cryptanalysis and modern stream cipher design?
4. *Zero-Trust Client Isolation:* Can a rich, feature-complete cryptographic analysis and export suite operate with zero external software dependencies, libraries, or server-side data transmissions, ensuring absolute client-side execution?

## 1.6 Aim and Formal Objectives
The primary **aim** of this major project is to design, implement, empirically verify, and document a production-grade, interactive, client-side educational software application dedicated to the Vigenère Cipher and classical polyalphabetic cryptanalysis.

To fulfill this aim, the project defines the following **formal objectives**:
1. **Mathematical Engine Design:** Formalize and implement the standard Vigenère encryption ($C \equiv (P + K) \pmod{26}$) and decryption ($P \equiv (C - K + 26) \pmod{26}$) functions in JavaScript (ES6+), ensuring full reversibility, case preservation, and keystream-invariant non-alphabetic passthrough.
2. **Dynamic Trace Generation:** Engineer a real-time Execution Matrix generator that constructs a comprehensive, tabular step-by-step audit trail for each character, itemizing character indices, ASCII code conversions, 0-indexed alphabetic values, keystream offsets, explicit algebraic formulas, and final transformed characters.
3. **Interactive Tabula Recta Raycasting:** Dynamically synthesize an interactive 26×26 Vigenère Tableau within the DOM, developing coordinate raycasting algorithms that visually highlight corresponding row headers, column headers, and intersection cells upon process-table hover.
4. **Visual Keystream Alignment:** Build a monospace alignment visualization component that clearly depicts the character-by-character mapping of the input plaintext, repeating expanded keystream, and resultant ciphertext.
5. **Statistical Lexical Analyzer:** Implement an asynchronous tokenizer that monitors user input in real time to calculate character frequencies, alphabetic density, whitespace ratios, digit counts, and key-to-text length metrics.
6. **Auxiliary Cryptographic Utilities:** Integrate a cryptographically safe Pseudo-Random Key Generator supporting standard educational key lengths (4 to 12 characters and custom lengths), multi-format analytical data exporters (plain text .txt, comma-separated values .csv, and direct clipboard serialization), and curated historical presets.
7. **Ergonomic Responsive UI:** Design a modern, accessible user interface featuring high-contrast dark and light themes, subtle grid aesthetic, mobile-responsive layout adapters, and clear validation feedback adhering to Nielsen Norman usability principles.
8. **Empirical Quality Assurance:** Formulate and execute a rigorous verification matrix comprising 15 formal test scenarios encompassing edge cases (empty strings, asymmetric lengths, symbol boundaries), followed by asymptotic computational complexity profiling.

## 1.7 Scope and Technical Delimitations
### Project Scope:
- The system models and executes the standard 26-letter English alphabet ($A$–$Z$, $a$–$z$) Vigenère cipher.
- The platform encompasses both cryptographic operations (encryption and decryption) alongside educational visualizers (Tabula Recta, Step Table, Alignment Monitor, Lexical Statistics).
- The system is architected as a standalone, zero-dependency client-side web application compatible with all modern, standards-compliant web browsers (Chromium, Gecko, WebKit engines).
- The platform includes comprehensive documentation, formal SRS specifications, architectural diagrams, mathematical proofs, test suites, and oral defense viva materials suitable for academic degree submission.

### Technical Delimitations:
- **Alphabet Boundary:** The cryptographic engine deliberately restricts modular shifting to the 26-letter Latin alphabet. It does not map extended Unicode characters (e.g., Cyrillic, Greek, accented Latin, Kanji) into an extended $\\mathbb{Z}_n$ ring, as doing so would obscure the historical and pedagogical context of classical European polyalphabetic systems.
- **Modern Security Non-Claim:** The application explicitly positions the Vigenère cipher as a historical and educational construct. It disclaims any fitness of the cipher for securing contemporary sensitive communications, actively educating users on its cryptanalytic vulnerabilities.
- **Serverless Architecture:** The application deliberately avoids server-side databases, REST APIs, or cloud backend services to enforce total client-side privacy and facilitate zero-configuration local execution (e.g., opening `index.html` directly from a local drive).

## 1.8 Thesis Organization
The remainder of this project report is systematically organized as follows:
- **Chapter 2 (Theoretical Foundations & Literature Review)** examines the historical evolution of cryptography from ancient monoalphabetic systems to polyalphabetic ciphers, details the underlying abstract algebra of modular residue rings ($\mathbb{Z}_{26}$), and surveys existing pedagogical tools.
- **Chapter 3 (Cryptanalysis of Polyalphabetic Systems)** delves into the mathematical mechanics of breaking the Vigenère cipher, providing rigorous derivations of the Kasiski Examination, Friedman's Index of Coincidence, Chi-Square goodness-of-fit testing, and Shannon's unicity distance.
- **Chapter 4 (Software Requirements Specification)** presents a formal SRS document encompassing stakeholder analysis, feasibility evaluations, and detailed functional (FR-01 to FR-15) and non-functional (NFR-01 to NFR-10) requirements.
- **Chapter 5 (System Architecture & Detailed Design)** articulates the system architecture, detailing Data Flow Diagrams (Levels 0, 1, 2), UML Class and Sequence diagrams, finite state machines, and interface wireframes.
- **Chapter 6 (Algorithmic Engineering & Mathematical Formulations)** provides formal set-theoretic definitions, keystream expansion mechanics, mathematical proofs of reversibility, complete pseudocodes, and asymptotic $O(N)$ computational complexity proofs.
- **Chapter 7 (Software Implementation & Technical Details)** presents an exhaustive, module-by-module breakdown of the source code architecture, DOM event binding, dynamic tableau generation, regex tokenization, and theme persistence.
- **Chapter 8 (Verification, Testing & Empirical Results)** documents the comprehensive quality assurance suite, detailing 15 rigorous test cases, stress tests up to 100,000 characters, browser compatibility benchmarks, and accessibility audits.
- **Chapter 9 (Case Studies, Comparative Analysis & Modern Perspectives)** conducts a practical, step-by-step cryptanalytic attack on an unknown ciphertext, presents a comprehensive comparison matrix against historical and modern ciphers (AES/DES), and evaluates pedagogical outcomes.
- **Chapter 10 (Limitations, Security Vulnerabilities & Future Scope)** critically appraises the system's structural constraints, assesses vulnerability profiles, and outlines roadmap enhancements including automated cracking assistants.
- **Chapter 11 (Conclusion & Project Summary)** synthesizes the project's intellectual contributions and practical milestones.
- **References & Appendices** provide formal academic literature citations, the complete 26×26 Tabula Recta matrix, fully annotated source code listings, a 50-question Viva-Voce examination preparation manual, and an operational user guide.

<div style="page-break-after: always;"></div>

---

# CHAPTER 2: THEORETICAL FOUNDATIONS & LITERATURE REVIEW

## 2.1 Taxonomy of Classical Cryptographic Systems
The domain of classical cryptography—encompassing all encryption techniques developed prior to the advent of digital computing and information theory in the mid-20th century—is fundamentally bifurcated into two primary architectural families:
1. **Transposition Ciphers:** In a transposition cipher, the identity of the characters remains strictly invariant; however, their physical spatial ordering is permuted according to a well-defined geometric or mathematical rule. Classical examples include the Spartan Scytale, the Rail Fence cipher, and columnar transposition systems.
2. **Substitution Ciphers:** In a substitution cipher, the relative spatial positions of characters remain static; however, the plaintext units (single letters, digraphs, or trigraphs) are systematically replaced with alternative ciphertext characters, numerals, or symbols according to a substitution mapping.

Substitution systems are further categorized based on their mapping cardinality:
- **Monoalphabetic Substitution:** A single fixed cryptographic alphabet is utilized across the entirety of the text. There exists an invariant bijective mapping $f: \\Sigma \\to \\Sigma$ between the plaintext alphabet and the ciphertext alphabet.
- **Polyalphabetic Substitution:** Multiple substitution alphabets are utilized sequentially across the message. The specific substitution alphabet applied to a given plaintext character varies dynamically as a function of the character's ordinal position within the string, determined by a periodic secret key or continuous running text.
- **Polygraphic Substitution:** Plaintext characters are grouped into blocks of size $m \\ge 2$ (e.g., pairs in the Playfair cipher, or vectors in the Hill cipher) and transformed simultaneously through matrix multiplication or lookup tables, significantly diminishing single-character statistical traits.

## 2.2 Monoalphabetic Substitution Systems and Their Structural Vulnerabilities
To understand the historical imperative that produced the Vigenère cipher, one must analyze the mathematical structural defect endemic to all monoalphabetic systems.

Consider the general monoalphabetic cipher over the standard alphabet $\\Sigma = \\{A, B, C, \\dots, Z\\}$ where $|\Sigma| = 26$. The cipher can be formalized as a permutation $\\pi \\in S_{26}$, where $S_{26}$ is the symmetric group of degree 26. The key space cardinality is:
$$|S_{26}| = 26! \\approx 4.0329 \\times 10^{26}$$

While a key space of $4 \\times 10^{26}$ might superficially appear impervious to brute-force exhaustive key search (even a modern supercomputer evaluating one billion keys per second would require over 12 million years to traverse the entire keyspace), monoalphabetic ciphers are utterly fragile when confronted with **frequency analysis**.

In natural human language, orthographic conventions dictate that individual phonemes and letters occur with wildly disparate, highly stable relative probabilities. Let $p(x)$ denote the probability of occurrence of character $x \\in \\Sigma$ in standard written English text. The probability distribution $P = \\{p(A), p(B), \\dots, p(Z)\\}$ is non-uniform and exhibits severe variance:
- High-frequency characters: $p(E) \\approx 0.12702$, $p(T) \\approx 0.09056$, $p(A) \\approx 0.08167$, $p(O) \\approx 0.07507$, $p(I) \\approx 0.06966$, $p(N) \\approx 0.06749$.
- Low-frequency characters: $p(J) \\approx 0.00153$, $p(X) \\approx 0.00150$, $p(Q) \\approx 0.00095$, $p(Z) \\approx 0.00074$.

Under any monoalphabetic substitution $\\pi$, if plaintext character $x$ maps to ciphertext character $y = \\pi(x)$, then the expected probability of $y$ in the ciphertext $C$ is identically equal to the probability of $x$ in the plaintext:
$$\\Pr[C_i = y] = \\Pr[P_i = \\pi^{-1}(y)] = p(x)$$

Consequently, an adversary need not search the $26!$ permutation space. By simply tallying the frequency histogram of the ciphertext characters and aligning the observed peaks and troughs with the standard unigram, bigram (e.g., *TH, HE, IN, ER*), and trigram (e.g., *THE, AND, ING*) profiles of the language, the substitution permutation $\\pi$ can be completely reconstructed within minutes, even with modest pencil-and-paper analysis.

## 2.3 The Evolution of Polyalphabetic Systems

### 2.3.1 Leon Battista Alberti and the Cipher Disk (1467)
Recognizing that monoalphabetic ciphers could never resist frequency analysis, the Italian architect, artist, and mathematician Leon Battista Alberti presented his seminal treatise *De Cifris* in 1467. Alberti conceptualized the world's first **cipher disk**—a mechanical device comprising two concentric brass wheels. The outer stationary ring was inscribed with the standard Latin alphabet (the plaintext alphabet), while the inner movable ring was inscribed with a scrambled 24-character alphabet (the ciphertext alphabet).

Alberti's revolutionary contribution was the concept of **polyalphabetic encipherment**: after writing a few words, the sender would rotate the inner disk by an agreed-upon offset, thereby switching to an entirely different substitution alphabet. In Alberti's system, the letter 'E' might initially map to 'X', but after rotating the disk, the subsequent instance of 'E' would map to 'M'. This historical invention earned Alberti the enduring title of the *"Father of Western Cryptology."*

### 2.3.2 Johannes Trithemius and the Polygraphia (1518)
In 1518, the German Benedictine abbot Johannes Trithemius published *Polygraphia*, the first printed book dedicated exclusively to cryptography. Trithemius made an enormous leap in systematizing polyalphabetic substitution by inventing the **Tabula Recta** (now known universally as the *Vigenère Tableau*). 

The Tabula Recta is a 26×26 square matrix of letters wherein the first row consists of the alphabet in standard order ($A$ to $Z$), and each subsequent row is cyclically shifted one position to the left relative to the row immediately preceding it. Trithemius proposed encrypting messages by enciphering the first letter using the first row, the second letter using the second row, the third with the third, and so on, cyclically stepping through all 26 rows. While Trithemius’s progression was deterministic and unkeyed (limiting its operational secrecy), his matrix established the structural foundation for all subsequent polyalphabetic developments.

### 2.3.3 Giovan Battista Bellaso’s Reciprocal Keyword System (1553)
The critical missing component in Trithemius’s Tabula Recta was a flexible, easily memorized secret key that could govern the selection of rows. In 1553, the Italian cryptologist Giovan Battista Bellaso published *La cifra del Sig. Giovan Battista Bellaso*. Bellaso introduced the concept of the **countersign** (keyword). 

Under Bellaso's scheme, both communicating parties agreed upon a secret word or phrase (e.g., `"VIRTUS"`). The keyword was written repeatedly above the plaintext message, character for character. Each character of the keyword specified which row of the Tabula Recta was to be utilized to encipher the corresponding plaintext letter beneath it. Bellaso had successfully invented the exact mathematical cipher that history would later mistakenly attribute to Vigenère.

### 2.3.4 Blaise de Vigenère’s Traicté des Chiffres (1586)
In 1586, the French diplomat and alchemist Blaise de Vigenère published *Traicté des Chiffres ou Secrètes Manières d'Escrire*. Vigenère was deeply familiar with the works of Alberti, Trithemius, and Bellaso. In his treatise, Vigenère introduced a distinct and mathematically superior cipher: the **Autokey Cipher**. 

Unlike Bellaso’s repeating keyword system (which introduces periodic vulnerabilities), Vigenère’s autokey scheme used a single secret primer letter to encipher the first character, after which the plaintext message itself served as the keystream for subsequent encipherment. Because the plaintext does not cyclically repeat, the cipher did not possess a short periodic cycle.

However, during the 19th century, historians and cryptologists conflated Bellaso’s repeating-key Tabula Recta cipher with Vigenère’s autokey system. The repeating-key cipher became universally known as the **"Vigenère Cipher,"** cementing Vigenère's name in cryptographic literature.

## 2.4 Mathematical Algebra of Residue Classes

### 2.4.1 Congruences and the Algebraic Ring $\mathbb{Z}_{26}$
To evaluate the Vigenère cipher with mathematical rigor, we construct an algebraic framework based on modular residue arithmetic.

Let $\\mathbb{Z}$ denote the ring of integers. For any positive integer $m \\in \\mathbb{Z}^+$, two integers $a, b \\in \\mathbb{Z}$ are said to be **congruent modulo $m$**, denoted as:
$$a \\equiv b \\pmod m$$
if and only if their difference $(a - b)$ is an integral multiple of $m$:
$$m \\mid (a - b) \\iff \\exists q \\in \\mathbb{Z} \\text{ such that } a - b = qm$$

The congruence relation modulo $m$ is an equivalence relation on $\\mathbb{Z}$, satisfying:
1. **Reflexivity:** $a \\equiv a \\pmod m, \\quad \\forall a \\in \\mathbb{Z}$
2. **Symmetry:** $a \\equiv b \\pmod m \\implies b \\equiv a \\pmod m$
3. **Transitivity:** $a \\equiv b \\pmod m \\text{ and } b \\equiv c \\pmod m \\implies a \\equiv c \\pmod m$

The set of equivalence classes modulo $m$ forms the **quotient ring of integers modulo $m$**, denoted as $\\mathbb{Z}/m\\mathbb{Z}$ or simply $\\mathbb{Z}_m$:
$$\\mathbb{Z}_m = \\{[0], [1], [2], \\dots, [m-1]\\}$$
In the context of the standard English alphabet, we instantiate $m = 26$. The algebraic domain is thus the finite residue ring:
$$\\mathbb{Z}_{26} = \\{0, 1, 2, \\dots, 25\\}$$

### 2.4.2 Group Properties of Additive Shifts $(\mathbb{Z}_{26}, +)$
The algebraic structure $(\\mathbb{Z}_{26}, +)$, where $+$ denotes standard modular addition:
$$[a] + [b] = [(a + b) \\pmod{26}]$$
satisfies the formal axioms of an **abelian (commutative) group**:
1. **Closure:** $\\forall a, b \\in \\mathbb{Z}_{26}, \\quad (a + b) \\pmod{26} \\in \\mathbb{Z}_{26}$.
2. **Associativity:** $\\forall a, b, c \\in \\mathbb{Z}_{26}, \\quad ((a + b) + c) \\equiv (a + (b + c)) \\pmod{26}$.
3. **Identity Element:** The unique additive identity is $0 \\in \\mathbb{Z}_{26}$, such that $\\forall a \\in \\mathbb{Z}_{26}$:
   $$a + 0 \\equiv 0 + a \\equiv a \\pmod{26}$$
4. **Inverse Element:** For every element $a \\in \\mathbb{Z}_{26}$, there exists a unique additive inverse $-a \\in \\mathbb{Z}_{26}$, given by:
   $$-a = (26 - a) \\pmod{26}$$
   such that:
   $$a + (-a) \\equiv a + (26 - a) \\equiv 26 \\equiv 0 \\pmod{26}$$
5. **Commutativity:** $\\forall a, b \\in \\mathbb{Z}_{26}, \\quad a + b \\equiv b + a \\pmod{26}$.

Because $(\\mathbb{Z}_{26}, +)$ is an abelian group, every shift operation is an automorphism of the group structure, ensuring that shifting by a key value produces a legitimate permutation over the set of alphabetic symbols.

### 2.4.3 Bijective Mappings between Alphabetic Symbols and $\mathbb{Z}_{26}$
Let $\\Sigma = \\{A, B, C, \\dots, Z\\}$ represent the ordered Latin alphabet. We define a canonical bijection $\\phi: \\Sigma \\to \\mathbb{Z}_{26}$:
$$\\phi(ch) = \\text{ord}(ch) - \\text{ord}('A')$$
where $\\text{ord}(ch)$ denotes the ASCII / Unicode integer code-point of the uppercase character $ch$. The inverse bijection $\\phi^{-1}: \\mathbb{Z}_{26} \\to \\Sigma$ is formalized as:
$$\\phi^{-1}(n) = \\text{chr}(n + \\text{ord}('A'))$$

Under this bijective mapping, character manipulations are translated seamlessly into arithmetic operations over the finite ring $\\mathbb{Z}_{26}$:
$$A \\leftrightarrow 0, \\quad B \\leftrightarrow 1, \\quad C \\leftrightarrow 2, \\quad \\dots, \\quad Z \\leftrightarrow 25$$

### 2.4.4 Modular Inverse and Homomorphic Character Shifts
Let $P_i \\in \\mathbb{Z}_{26}$ represent the numerical value of the $i$-th plaintext letter, and let $K_i \\in \\mathbb{Z}_{26}$ represent the numerical value of the corresponding keystream letter. The Vigenère encryption transformation is the mapping:
$$E_{K_i}: \\mathbb{Z}_{26} \\to \\mathbb{Z}_{26}, \\quad E_{K_i}(P_i) = (P_i + K_i) \\pmod{26}$$

The decryption transformation requires computing the inverse mapping $D_{K_i} = E_{K_i}^{-1}$. Because $(\\mathbb{Z}_{26}, +)$ is an additive group, the inverse of shifting forward by $K_i$ is shifting backward by $K_i$, which is mathematically equivalent to adding the additive inverse of $K_i$:
$$D_{K_i}(C_i) = (C_i - K_i) \\pmod{26} = (C_i + (26 - K_i)) \\pmod{26}$$

**Theorem 2.1 (Decryption Invertibility):**  
*For any plaintext symbol $P_i \\in \\mathbb{Z}_{26}$ and any key symbol $K_i \\in \\mathbb{Z}_{26}$, the composition of decryption and encryption functions yields the original plaintext symbol: $D_{K_i}(E_{K_i}(P_i)) = P_i$.*

*Proof:*
$$\\begin{aligned}
D_{K_i}(E_{K_i}(P_i)) &= D_{K_i}((P_i + K_i) \\pmod{26}) \\\\
&= [((P_i + K_i) \\pmod{26}) - K_i + 26] \\pmod{26} \\\\
&\\equiv (P_i + K_i - K_i + 26) \\pmod{26} \\\\
&\\equiv (P_i + 26) \\pmod{26} \\\\
&\\equiv P_i \\pmod{26}
\\end{aligned}$$
Since $P_i \\in \\{0, 1, \\dots, 25\\}$, $P_i \\pmod{26} = P_i$. Hence, invertibility is rigorously guaranteed. $\\blacksquare$

## 2.5 Comparative Literature Survey of Classical Ciphers
To contextualize the architectural trade-offs inherent in the Vigenère cipher, Table 2.1 synthesizes a comprehensive comparative survey across foundational classical substitution ciphers.

| Cipher Name | Era / Originator | Algorithmic Paradigm | Mathematical Formulation | Typical Key Space ($|\\mathcal{K}|$) | Susceptibility to Simple Frequency Analysis |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Caesar Cipher** | ~50 BCE, Julius Caesar | Monoalphabetic Shift | $C \\equiv (P + 3) \\pmod{26}$ | $25$ (trivial) | Extremely High (Instant compromise via letter histogram) |
| **Affine Cipher** | Classical Antiquity | Monoalphabetic Linear | $C \\equiv (aP + b) \\pmod{26}, \\gcd(a, 26)=1$ | $12 \\times 26 = 312$ | Extremely High (2 linear equations solve $a$ and $b$) |
| **Atbash Cipher** | Biblical Antiquity | Monoalphabetic Reflection | $C \\equiv (25 - P) \\pmod{26}$ | $1$ (Keyless) | Total (Zero security; direct inverse reflection) |
| **Vigenère Cipher** | 1553, G. B. Bellaso | Polyalphabetic Periodic | $C_i \\equiv (P_i + K_{i \\pmod m}) \\pmod{26}$ | $26^m$ ($m = \\text{key length}$) | Immune to direct unigram analysis; vulnerable to periodic decomposition |
| **Autokey Cipher** | 1586, B. de Vigenère | Polyalphabetic Non-Periodic | $C_i \\equiv (P_i + P_{i - d}) \\pmod{26}$ | $26$ (Primer key) | Moderate (Vulnerable to Friedman autokey cryptanalysis) |
| **Playfair Cipher** | 1854, Charles Wheatstone | Polygraphic Digram ($2 \\times 2$) | 5×5 Matrix Geometric Rules | $25! \\approx 1.55 \\times 10^{25}$ | Low for unigrams; highly vulnerable to digram frequency analysis |
| **Hill Cipher** | 1929, Lester S. Hill | Polygraphic Linear Algebraic | $\\mathbf{C} \\equiv \\mathbf{K} \\cdot \\mathbf{P} \\pmod{26}$ | $|GL(n, \\mathbb{Z}_{26})|$ | Highly resistant to ciphertext-only; broken instantly via Known-Plaintext Attack |
| **One-Time Pad** | 1917, Gilbert Vernam | Polyalphabetic Non-Periodic | $C_i \\equiv (P_i \\oplus K_i) \\text{ or } (P_i + K_i) \\pmod{26}$ | Infinite / Continuous | **Unbreakable** (Information-theoretically secure if key is truly random & unshared) |

*Table 2.1: Comprehensive Comparative Survey of Classical Substitution Ciphers.*

## 2.6 Critical Analysis of Existing Pedagogical Software & Research Gaps
Despite the existence of various web-based cryptographic demonstrations, a rigorous survey of contemporary educational software reveals persistent pedagogical and technological deficiencies:

1. **The "Black-Box" Fallacy:** Most consumer cryptographic calculators simply accept an input string and produce a transformed ciphertext string. They omit the intermediate operational telemetry—specifically, how ASCII characters map to integers, how the modulo arithmetic wraps around 26, and how the repeating keystream pointers increment.
2. **Keystream Corruption on Non-Alphabetic Glyphs:** A widespread engineering defect in amateur Vigenère implementations is the naive advancement of the keystream index on whitespace, punctuation marks, and numerals. Classical cryptographic standards dictate that non-alphabetic glyphs must either be removed or preserved without consuming a keystream character. Advancing the keystream on non-letters fundamentally corrupts keystream alignment and desynchronizes periodic cryptanalysis demonstrations.
3. **Absence of Coordinated Visual Feedback:** Existing tools that feature a Tabula Recta display it merely as an inert, static graphic image or an isolated table. None provide real-time, bidirectional coordinate raycasting linking individual table cells to corresponding character transformations in the message.
4. **Third-Party Telemetry and Security Concerns:** Many legacy web applets load remote tracking scripts (e.g., Google Analytics, advertising SDKs) or rely on obsolete runtime plugins (Java Applets, Flash) that present severe security vulnerabilities in modern browser runtimes.

This project explicitly remedies these identified research gaps by delivering an engineered, zero-dependency, client-isolated cryptographic environment tailored for academic computer science pedagogy.

<div style="page-break-after: always;"></div>

---

# CHAPTER 3: CRYPTANALYSIS OF POLYALPHABETIC SYSTEMS

## 3.1 The Three-Century Myth of "Le Chiffre Indéchiffrable"
For more than three hundred years following its introduction, the Vigenère cipher was deemed invulnerable to cryptanalysis. Prominent mathematicians, diplomats, and literary figures—including the 19th-century author Lewis Carroll (Charles Lutwidge Dodgson), who extolled its virtues in an 1868 article—believed that polyalphabetic substitution eliminated every mathematical trace of the underlying language.

The myth of *le chiffre indéchiffrable* rested on a single, superficially compelling premise: because a given plaintext letter (e.g., 'E') is enciphered with multiple different keys across a message, it can map to any of the 26 ciphertext letters with equal ease. Similarly, an identical ciphertext character (e.g., 'X') could represent any possible plaintext character depending on the governing key character. 

However, this assumption of security conflated **local variability** with **global statistical independence**. The fatal vulnerability of the Vigenère cipher is its **periodicity**: because human users invariably employ finite, memorable secret keywords (typically ranging from 4 to 12 characters in length), the cipher alphabets cycle with strict, invariant regularity.

## 3.2 Statistical Properties of Natural Languages
To formalize the cryptanalysis of polyalphabetic ciphers, we examine the quantitative statistical invariants of natural human language, focusing on written English.

Let $N$ represent the total character length of a sample text composed over the 26-letter alphabet $\\Sigma$. Let $f_i$ represent the observed absolute frequency count of character $i \\in \\{A, B, \\dots, Z\\}$, such that $\\sum_{i=0}^{25} f_i = N$. The observed relative frequency (probability) is defined as:
$$p_i = \\frac{f_i}{N}$$

In written English literary corpora (analyzed across billions of characters), the canonical letter probability distribution is highly asymmetric, as summarized in Table 3.1.

| Letter | Probability ($p_i$) | Letter | Probability ($p_i$) | Letter | Probability ($p_i$) | Letter | Probability ($p_i$) |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **E** | 0.12702 | **R** | 0.05987 | **F** | 0.02228 | **K** | 0.00772 |
| **T** | 0.09056 | **D** | 0.04253 | **W** | 0.02360 | **J** | 0.00153 |
| **A** | 0.08167 | **L** | 0.04025 | **M** | 0.02406 | **X** | 0.00150 |
| **O** | 0.07507 | **C** | 0.02782 | **P** | 0.01929 | **Q** | 0.00095 |
| **I** | 0.06966 | **U** | 0.02758 | **G** | 0.02015 | **Z** | 0.00074 |
| **N** | 0.06749 | **S** | 0.06327 | **Y** | 0.01974 | | |
| **S** | 0.06327 | **H** | 0.06094 | **B** | 0.01492 | | |

*Table 3.1: Standard English Letter Frequency Table ($p_i$) in Decreasing Order.*

```
Relative Frequency (%)
  14% |   [E]
  12% |    |
  10% |    |      [T]  [A]  [O]
   8% |    |       |    |    |   [I]  [N]  [S]  [H]  [R]
   6% |    |       |    |    |    |    |    |    |    |   [D]  [L]
   4% |    |       |    |    |    |    |    |    |    |    |    |   [C]  [U]  [M]  [F]
   2% |    |       |    |    |    |    |    |    |    |    |    |    |    |    |    |   [P] ... [Z]
   0% +--------------------------------------------------------------------------------------->
          E       T    A    O    I    N    S    H    R    D    L    C    U    M    F    P ...  Z
```
*Figure 3.1: Standard Monogram Frequency Distribution of the English Language.*

## 3.3 Frequency Smoothing and the Flattening Effect
When a message of length $N$ is enciphered using a Vigenère cipher parameterized by a key of length $m$, the ciphertext does not exhibit the sharp, jagged unigram distribution depicted in Figure 3.1. Instead, the frequency distribution undergoes **statistical smoothing**.

Because each character of the ciphertext is generated by one of $m$ distinct Caesar shifts, the overall probability of observing ciphertext character $c \\in \\mathbb{Z}_{26}$ is the average across all $m$ shifts:
$$\\Pr[C = c] = \\frac{1}{m} \\sum_{j=0}^{m-1} p_{(c - K_j) \\pmod{26}}$$

As the key length $m$ increases relative to the message length, the variance of this distribution decays asymptotically. If a keystream were infinitely long, non-repeating, and uniformly distributed, the probability of every ciphertext letter would converge to uniform randomness:
$$\\lim_{m \\to \\infty} \\Pr[C = c] = \\frac{1}{26} \\approx 0.03846 \\quad (\\approx 3.85\\%)$$

```
Frequency Variance
     ^
High |  Monoalphabetic (Caesar) - Jagged Distribution (Var ≈ 0.00138)
     |    /\
     |   /  \    /\
     |  /    \  /  \  /\
     | /      \/    \/  \
     |--------------------------------------------
     |  Polyalphabetic (m = 5) - Moderately Smoothed (Var ≈ 0.00032)
     |    ~~~~~~~~~~~~
     |--------------------------------------------
     |  Uniform Random / OTP - Completely Flat Line (Var = 0.00000, P = 1/26)
Low  |  ==========================================
     +----------------------------------------------------> Character Space (A-Z)
```
*Figure 3.2: Frequency Flattening Phenomenon as Keystream Length Increases.*

The historical triumph of polyalphabetic cryptanalysis lay in recognizing that despite this flattening of global unigram frequencies, **periodic spatial correlations** remain preserved within the ciphertext.

## 3.4 Charles Babbage's Uncredited Breakthrough (1854)
The first mathematical breakthrough in breaking the Vigenère cipher was achieved by the British polymath, mathematician, and computer pioneer **Charles Babbage** in 1854. Babbage was challenged by John Hall Brock Thwaites to decipher a message enciphered with a secret keyword. Thwaites claimed his cipher was a new, unbreakable invention; Babbage immediately identified it as a variant of the Vigenère cipher.

Babbage deduced that if a word or common n-gram (e.g., *"THE"*, *"AND"*, *"THAT"*) occurs multiple times in the plaintext, and if the distance between these occurrences happens to be an exact integer multiple of the key length $m$, then **the identical plaintext sequence will be enciphered using the exact same keystream characters**. As a consequence, the identical multi-character sequence will repeat in the ciphertext.

By measuring the distances between repeated ciphertext sequences and factoring out their common divisors, Babbage successfully derived the key length $m$. Once $m$ was determined, he divided the ciphertext into $m$ independent monoalphabetic Caesar ciphers and solved each via standard frequency analysis. However, because Babbage was employed as a military cryptographic advisor during the Crimean War, the British government classified his research, leaving the public discovery to be credited to Friedrich Kasiski nine years later.

## 3.5 Friedrich Kasiski’s Periodic Examination (1863)

### 3.5.1 The Probability of Polyalphabetic Coincidence
In 1863, the Prussian military officer and cryptanalyst **Friedrich Kasiski** published *Die Geheimschriften und die Dechiffrir-Kunst* (Writing in Cipher and the Art of Deciphering), providing the world's first published, systematic method for breaking polyalphabetic ciphers: the **Kasiski Examination**.

Kasiski formalized the observation that in any sufficiently lengthy text, natural lexical repetitions are abundant. Let $S = (s_1, s_2, \\dots, s_k)$ be an n-gram sequence of length $k \\ge 3$ occurring at indices $i$ and $j$ in the plaintext ($j > i$). The distance separating these occurrences is:
$$\\Delta = j - i$$

The identical sequence will appear in the ciphertext at positions $i$ and $j$ if and only if the keystream repeats at the exact same phase offset:
$$i \\equiv j \\pmod m \\iff (j - i) \\equiv 0 \\pmod m \\iff m \\mid \\Delta$$

While it is mathematically possible for two identical ciphertext n-grams to appear purely by random chance (an accidental coincidence), for sequences of length $k \\ge 3$, the probability of random occurrence is vanishingly small:
$$\\Pr[\\text{Random match of length } k] = \\left(\\frac{1}{26}\\right)^k$$
For trigrams ($k = 3$), this probability is $\\frac{1}{17576} \\approx 0.0000569$. Thus, repeated trigrams in a ciphertext almost invariably indicate structural alignments where the interval distance $\\Delta$ is a multiple of the key length $m$.

### 3.5.2 Greatest Common Divisor (GCD) Factorization
The operational procedure of the Kasiski Examination is formalized as follows:
1. Scan the ciphertext $C$ for all repeated strings of length $k \\ge 3$.
2. For each repeated sequence, record its positional occurrences $\\{pos_1, pos_2, \\dots, pos_r\\}$.
3. Calculate all pairwise distance deltas:
   $$\\Delta_{a, b} = pos_b - pos_a, \\quad \\forall b > a$$
4. Compute the integer prime factorizations of all observed distances $\\{\\Delta\\}$.
5. Identify the **Greatest Common Divisor (GCD)** that appears with highest statistical frequency across the factor sets. The most prevalent divisor represents the probable key length $m$.

### 3.5.3 Complete Mathematical Derivation & Numerical Walkthrough
To demonstrate this algorithm, consider an intercepted ciphertext containing repeated occurrences of the trigram sequence `"VHN"`:
- Occurrence 1: Character Index 42
- Occurrence 2: Character Index 87
- Occurrence 3: Character Index 147
- Occurrence 4: Character Index 237

We calculate the pairwise distance intervals:
$$\\begin{aligned}
\\Delta_{1, 2} &= 87 - 42 = 45 \\\\
\\Delta_{2, 3} &= 147 - 87 = 60 \\\\
\\Delta_{3, 4} &= 237 - 147 = 90 \\\\
\\Delta_{1, 3} &= 147 - 42 = 105 \\\\
\\Delta_{1, 4} &= 237 - 42 = 195
\\end{aligned}$$

Next, we extract the complete set of integer divisors for each delta:
- Divisors of $45$: $\\{3, 5, 9, 15, 45\\}$
- Divisors of $60$: $\\{2, 3, 4, 5, 6, 10, 12, 15, 20, 30, 60\\}$
- Divisors of $90$: $\\{2, 3, 5, 6, 9, 10, 15, 18, 30, 45, 90\\}$
- Divisors of $105$: $\\{3, 5, 7, 15, 21, 35, 105\\}$
- Divisors of $195$: $\\{3, 5, 13, 15, 39, 65, 195\\}$

We compute the greatest common divisor across all intervals:
$$\\gcd(45, 60, 90, 105, 195) = 15$$
The divisor candidates are $3$, $5$, and $15$. In cryptographic practice, a key of length 3 is typically too short to evade basic inspection, while a key of length 15 (or one of its subfactors, 5) perfectly matches the observed periodicity. Subsequent frequency tests can instantly confirm whether the candidate key length is $m = 5$ or $m = 15$.

## 3.6 William F. Friedman’s Index of Coincidence (1922)

### 3.6.1 Definition of $I_c$ and Combinatorial Derivation
In 1922, the pioneering American cryptanalyst **William F. Friedman** published *The Index of Coincidence and Its Applications in Cryptanalysis*. Friedman introduced the first rigorous statistical metric capable of calculating key length without requiring repeated n-gram sequences: the **Index of Coincidence ($I_c$)**.

The Index of Coincidence is defined as the probability that two characters chosen uniformly at random from a given text sample are identical.

Let a text of length $N$ have letter frequencies $f_0, f_1, \\dots, f_{25}$ representing counts for $A$ through $Z$. The total number of ways to select an unordered pair of characters from the text is given by the binomial coefficient:
$$\\binom{N}{2} = \\frac{N(N - 1)}{2}$$

The number of ways to select a pair of identical characters of type $i$ is:
$$\\binom{f_i}{2} = \\frac{f_i(f_i - 1)}{2}$$

Summing over all 26 letters of the alphabet, the total number of identical pairs is $\\sum_{i=0}^{25} \\frac{f_i(f_i - 1)}{2}$. Dividing this by the total possible pairs yields the formal definition of the Index of Coincidence:
$$I_c = \\frac{\\sum_{i=0}^{25} f_i(f_i - 1)}{N(N - 1)}$$

### 3.6.2 Derivation of Expected $I_c$ for English vs. Random Text
To understand how $I_c$ operates as a cryptographic discriminator, we evaluate its theoretical expectation under two distinct boundary conditions:
1. **Natural Written English ($I_{\\text{English}}$):**  
   In infinitely long natural English text, the probability that two randomly selected characters are identical is:
   $$\\mathbb{E}[I_{\\text{English}}] = \\sum_{i=0}^{25} p_i^2$$
   Substituting the canonical probabilities $p_i$ from Table 3.1:
   $$\\begin{aligned}
   \\mathbb{E}[I_{\\text{English}}] &= (0.12702)^2 + (0.09056)^2 + (0.08167)^2 + \\dots + (0.00074)^2 \\\\
   &\\approx 0.01613 + 0.00820 + 0.00667 + \\dots \\\\
   &\\approx 0.0667 \\quad (\\approx 6.67\\%)
   \\end{aligned}$$

2. **Uniformly Distributed Random Text ($I_{\\text{Random}}$):**  
   In a text where each of the 26 characters occurs with equal probability $p_i = \\frac{1}{26}$:
   $$\\mathbb{E}[I_{\\text{Random}}] = \\sum_{i=0}^{25} \\left(\\frac{1}{26}\\right)^2 = 26 \\times \\frac{1}{676} = \\frac{1}{26} \\approx 0.03846 \\quad (\\approx 3.85\\%)$$

This fundamental discrepancy—**$0.0667$ for human language versus $0.0385$ for random noise**—provides the mathematical foundation for cryptanalytic detection. A monoalphabetic substitution (Caesar cipher) preserves character frequencies intact; hence, its $I_c$ remains identically $\\approx 0.0667$. In contrast, as polyalphabetic key length increases, character frequencies flatten, causing the overall $I_c$ of the ciphertext to degrade toward $0.0385$.

### 3.6.3 Key Length Estimation Formula
Friedman leveraged this divergence to formulate an equation that directly estimates the key length $m$ of a Vigenère cipher from the observed $I_c$ of the ciphertext.

Let a ciphertext of length $N$ be enciphered with a key of length $m$. The ciphertext can be partitioned into $m$ distinct interleaved cosets (columns), each of length approximately $n = N/m$. 
- Pairs of characters chosen from the **same** coset share the same Caesar shift and exhibit English coincidence: $I_{\\text{English}} \\approx 0.0667$.
- Pairs of characters chosen from **different** cosets exhibit mutual random coincidence: $I_{\\text{Random}} \\approx 0.0385$.

By setting up a weighted expectation equation based on the probability of selecting pairs from the same coset versus different cosets:
$$I_c \\approx \\frac{1}{m} I_{\\text{English}} + \\left(1 - \\frac{1}{m}\\right) I_{\\text{Random}}$$

Substituting numerical constants $I_{\\text{English}} \\approx 0.0667$ and $I_{\\text{Random}} \\approx 0.0385$:
$$I_c \\approx \\frac{0.0667}{m} + 0.0385 - \\frac{0.0385}{m} = 0.0385 + \\frac{0.0282}{m}$$

Solving algebraically for the key length $m$, and applying finite-sample bias corrections for text length $N$, yields **Friedman's Key Length Estimator**:
$$m \\approx \\frac{0.0282 \\cdot N}{(N - 1)I_c - 0.0385N + 0.0667}$$

### 3.6.4 Mutual Index of Coincidence ($MIC$) and Cross-Correlation
Once the candidate key length $m$ is established, the ciphertext is segregated into $m$ independent subsets:
$$\\mathcal{C}_j = \\{c_i \\mid i \\equiv j \\pmod m\\}, \\quad \\text{for } j \\in \\{0, 1, \\dots, m-1\\}$$
Each coset $\\mathcal{C}_j$ is a simple Caesar cipher enciphered with key character $K_j$.

To determine the relative key offsets between different columns $\\mathcal{C}_a$ and $\\mathcal{C}_b$ without testing full alphabets, cryptanalysts utilize the **Mutual Index of Coincidence ($MIC$)**, also termed the *Cross-Index of Coincidence*. Let $f_i^{(a)}$ and $f_i^{(b)}$ denote letter frequencies in cosets $a$ and $b$ of lengths $N_a$ and $N_b$. For any trial shift $s \\in \\{0, 1, \\dots, 25\\}$:
$$MIC(a, b; s) = \\frac{\\sum_{i=0}^{25} f_i^{(a)} \\cdot f_{(i + s) \\pmod{26}}^{(b)}}{N_a \\cdot N_b}$$

When trial shift $s$ matches the true relative key difference $(K_b - K_a) \\pmod{26}$, the value of $MIC$ spikes dramatically from the random baseline of $0.0385$ up to the English threshold $\\approx 0.0667$. This allows all $m$ key characters to be mutually locked into correct relative alignment, reducing the remaining search space to just 26 global Caesar shifts!

## 3.7 Chi-Square ($\chi^2$) Goodness-of-Fit Metric for Column Caesar Shifts
To recover the absolute key character $K_j$ for each of the $m$ isolated monoalphabetic cosets $\\mathcal{C}_j$, we employ Pearson's **Chi-Square ($\\chi^2$) Goodness-of-Fit test**.

Let $n$ denote the length of coset $\\mathcal{C}_j$. For each hypothesized key shift $k \\in \\{0, 1, \\dots, 25\\}$, we decrypt the column using shift $k$ and calculate the observed frequency $O_i$ of each letter $i \\in \\{A, \\dots, Z\\}$. The expected frequency $E_i$ based on natural English language probability is:
$$E_i = n \\cdot p_i$$
where $p_i$ is the canonical unigram probability from Table 3.1.

The Chi-Square statistic for candidate key $k$ is calculated as:
$$\\chi^2(k) = \\sum_{i=0}^{25} \\frac{(O_i - E_i)^2}{E_i}$$

The value of $k$ that minimizes the $\\chi^2(k)$ statistic represents the statistically optimal Caesar shift. Repeating this minimization independently across all $m$ columns completely reconstructs the secret key $\\mathbf{K} = (K_0, K_1, \\dots, K_{m-1})$ with near-perfect accuracy.

## 3.8 Information Theory & Unicity Distance (Claude Shannon, 1949)
In 1949, the father of digital communications, **Claude Shannon**, published the foundational paper *Communication Theory of Secrecy Systems* in the *Bell System Technical Journal*. Shannon formulated the mathematical limits of cryptographic security using information entropy.

Shannon defined the **entropy** $H(X)$ of a discrete random variable $X$ with probability mass function $P(X)$ as:
$$H(X) = -\\sum_{x \\in \\mathcal{X}} P(x) \\log_2 P(x)$$

For written English text, while the theoretical maximum entropy of a 26-letter alphabet is $\\log_2(26) \\approx 4.70$ bits per letter, the actual statistical entropy $R_L$ of natural English (accounting for orthographic redundancy, grammar, and vocabulary constraints) is only approximately:
$$R_L \\approx 1.0 \\text{ to } 1.5 \\text{ bits/character}$$

The **redundancy** $D$ of the English language is therefore:
$$D = R_0 - R_L = \\log_2(26) - 1.25 \\approx 4.70 - 1.25 = 3.45 \\text{ bits/character}$$

Shannon defined the **Unicity Distance ($U$)** as the minimum amount of ciphertext required for an adversary possessing infinite computational power to uniquely determine the encryption key without spurious decipherments. The unicity distance is formulated as:
$$U = \\frac{H(K)}{D}$$
where $H(K)$ is the entropy of the key space.

For a Vigenère cipher with a truly random keyword of length $m$:
$$H(K) = \\log_2(26^m) = m \\log_2(26) \\approx 4.70m \\text{ bits}$$

Substituting into Shannon's unicity distance formula:
$$U = \\frac{4.70 m}{3.45} \\approx 1.36 m$$

**Crucial Cryptographic Implication:**  
*For a Vigenère cipher utilizing a key of length $m$, an intercepted ciphertext of merely $1.36 \\times m$ characters is mathematically sufficient to uniquely determine the secret key!*  
For instance, if an adversary intercepts a ciphertext of just 15 characters enciphered with a 10-character key ($1.36 \\times 10 = 13.6$), there is sufficient information theoretic redundancy in the ciphertext to strip away all spurious keys and reconstruct the unique plaintext. This formalizes why the Vigenère cipher cannot withstand modern computational cryptanalysis.

<div style="page-break-after: always;"></div>
"""
