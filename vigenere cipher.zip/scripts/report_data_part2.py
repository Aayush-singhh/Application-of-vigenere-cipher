# scripts/report_data_part2.py
"""
Part 2 of the 70-Page B.Tech Project Report:
- Chapter 4: Software Requirements Specification (SRS)
- Chapter 5: System Architecture & Detailed Design (DFD, UML, State Transitions, Wireframes)
- Chapter 6: Algorithmic Engineering & Mathematical Formulations (Proofs, Pseudocode, Flowcharts, Complexity Analysis)
"""

CHAPTERS_4_TO_6 = """# CHAPTER 4: SOFTWARE REQUIREMENTS SPECIFICATION (SRS)

## 4.1 Purpose, Scope, and Overview
This Software Requirements Specification (SRS) document details the complete functional and non-functional requirements for the **Interactive Vigenère Cipher Educational Platform**. The software is engineered as a high-performance, zero-dependency, client-side web application designed to facilitate rigorous computer science instruction in classical cryptography, modular residue arithmetic, and periodic cryptanalysis.

The intended audience includes computer science undergraduates, cybersecurity researchers, academic instructors, and independent cryptography enthusiasts. The system provides an interactive, transparent simulation environment that demystifies every atomic stage of polyalphabetic substitution while strictly preserving user privacy through 100% client-isolated computation.

## 4.2 Comprehensive Feasibility Analysis
Before committing to software architecture and implementation, an exhaustive five-dimensional feasibility study was conducted.

### 4.2.1 Technical Feasibility
The platform requires modern web technologies: HTML5, CSS3 Custom Properties, and ECMAScript 6+ JavaScript. Modern browser JavaScript engines (such as Google V8 in Chromium, SpiderMonkey in Mozilla Firefox, and JavaScriptCore in Apple WebKit) execute standard modular arithmetic and array operations in sub-microsecond timeframes. Since the algorithm operates in linear $O(N)$ time complexity, client-side execution for text payloads up to 100,000 characters is effortlessly supported without specialized hardware, graphics accelerators, or external web service dependencies. Thus, the project is technically feasible.

### 4.2.2 Economic Feasibility
The project strictly adopts open-source, standards-compliant web technologies. No commercial libraries, proprietary software licenses, cloud database instances, or paid third-party hosting infrastructures are required. The entire system can be served statically via local file systems (e.g., `file:///` URI scheme) or free static hosting (GitHub Pages, Vercel, Firebase Hosting). Development, deployment, and operational maintenance costs are virtually zero, establishing economic viability.

### 4.2.3 Operational Feasibility
From an end-user perspective, the software requires zero installation, compilation, or environment configuration. Any user with a modern web browser on Windows, macOS, Linux, Android, or iOS can immediately execute the application by simply opening `index.html`. The graphical user interface conforms to established Nielsen Norman human-computer interaction heuristics, ensuring operational feasibility across varying levels of technical proficiency.

### 4.2.4 Schedule & Legal Feasibility
Development was structured across a four-week lifecycle encompassing requirement analysis, algorithmic formulation, core engine implementation, visual component design, verification testing, and formal documentation. Legally, the Vigenère cipher is a historical public-domain algorithm published in 1553, presenting zero intellectual property or patent encumbrances. The platform enforces complete client-side data isolation, adhering strictly to global data protection mandates (GDPR, California Consumer Privacy Act) by design.

## 4.3 Stakeholder Analysis & User Personas
The system architecture was informed by three primary stakeholder personas:
1. **Undergraduate Computer Science Student ("Alex"):** Needs to visualize how abstract mathematical formulas from discrete mathematics ($C \equiv (P + K) \pmod{26}$) translate into actual character substitutions; requires step-by-step traces to verify manual homework assignments.
2. **University Cryptography Instructor ("Dr. Evelyn"):** Requires an engaging lecture demonstration tool to show the relationship between keyword periodic repetition and Tabula Recta coordinate mapping, needing immediate visual feedback during live classroom projections.
3. **Curious Cybersecurity Practitioner ("Marcus"):** Interested in generating test ciphertexts to benchmark custom cryptanalytic scripts (Kasiski factoring, Index of Coincidence calculators), requiring one-click analytical exports to CSV and TXT formats.

## 4.4 Detailed Functional Requirements

### FR-01: Polyalphabetic Encryption Engine
- **Description:** The system shall encrypt arbitrary plaintext input using the standard Vigenère polyalphabetic cipher algorithm.
- **Inputs:** Plaintext message string ($P$), secret keyword string ($K$).
- **Processing:** Normalize key to uppercase alphabetic characters; iteratively map each alphabetic plaintext character $P_i$ to $C_i \equiv (P_i + K_j) \pmod{26}$; advance key index $j$ only on alphabetic processing.
- **Outputs:** Ciphertext string ($C$).
- **Preconditions:** Valid plaintext and alphabetic key are provided.
- **Postconditions:** Generated ciphertext is rendered in the read-only output panel.

### FR-02: Inverse Polyalphabetic Decryption Engine
- **Description:** The system shall decrypt arbitrary ciphertext input using the inverse Vigenère algorithm.
- **Inputs:** Ciphertext message string ($C$), secret keyword string ($K$).
- **Processing:** Normalize key; iteratively compute $P_i \equiv (C_i - K_j + 26) \pmod{26}$; advance key index $j$ only on alphabetic processing.
- **Outputs:** Reconstructed plaintext string ($P$).
- **Postconditions:** Decrypted message is rendered in the result panel.

### FR-03: Keystream Periodic Expander and Spatial Aligner
- **Description:** The system shall compute and render a character-by-character visual alignment displaying the input message, the expanded repeating keystream, and the resultant output in a monospace pre-formatted layout.
- **Processing:** Align non-alphabetic positions with matching whitespace or hyphens (`-`) while keeping the key characters strictly aligned beneath their corresponding transformed alphabetic letters.

### FR-04: Non-Alphabetic Invariant Passthrough
- **Description:** The cryptographic engine shall preserve all spaces, punctuation marks, digits, and special characters unmodified.
- **Invariant Rule:** The keystream pointer must NOT advance when a non-alphabetic character is encountered.

### FR-05: Case-Preservation Fidelity
- **Description:** The engine shall preserve the original case of each alphabetic character (uppercase remains uppercase, lowercase remains lowercase).
- **Processing:** Perform modular shift against base offset 65 for uppercase (`A`-`Z`) and 97 for lowercase (`a`-`z`).

### FR-06: Strict Input Validation and Dynamic Error Feedback
- **Description:** The system shall validate user inputs prior to cryptographic processing.
- **Validation Rules:**
  - Plaintext/Ciphertext cannot be empty or purely whitespace.
  - Secret key must contain at least one valid alphabetic character ($A$–$Z$).
- **Error Feedback:** Render prominent error text beneath invalid input fields and apply CSS shake animations to alert the user.

### FR-07: Dynamic Step-by-Step Execution Matrix
- **Description:** The system shall generate a detailed execution table containing an audit record for every character processed.
- **Table Schema:** Position Index | Input Character | Numeric Value ($0$–$25$ or `-`) | Keystream Character | Keystream Value ($0$–$25$ or `-`) | Algebraic Congruence Equation | Result Character.

### FR-08: Interactive 26×26 Tabula Recta with Bidirectional Raycasting
- **Description:** The system shall render a full 26×26 Vigenère matrix within a collapsible panel.
- **Interaction:** Hovering over any row in the Step-by-Step Execution Matrix shall automatically illuminate the corresponding Row Header, Column Header, and intersection Cell within the Tabula Recta using dual-tone coordinate highlights.

### FR-09: Real-Time Lexical & Cryptographic Statistical Monitor
- **Description:** The platform shall calculate and display dynamic lexical metrics updated asynchronously upon every keystroke in the input text areas.
- **Metrics Tracked:** Total Character Count, Total Alphabetic Letter Count, Whitespace Count, Digit Count, Special Symbol Count, Active Keystream Length.

### FR-10: Cryptographically Safe Random Key Generator
- **Description:** The system shall generate uniform, pseudo-random alphabetic keys across selectable preset lengths (4, 6, 8, 10, 12 characters) or arbitrary custom lengths.
- **Feature:** Provide a one-click *"Use This Key"* button that automatically populates the active key field and recalculates statistics.

### FR-11: Predefined Educational Exemplars
- **Description:** The system shall provide one-click clickable cards that populate the workspace with canonical historical examples:
  - Example 1: Classic Military Test (`"ATTACK AT DAWN"` / `"LEMON"` $\to$ `"LXFOPV EF RNHR"`).
  - Example 2: Short Periodic Key (`"HELLO WORLD"` / `"KEY"` $\to$ `"RIJVS UYVJN"`).
  - Example 3: Mixed Alphanumeric Invariance (`"Hello, World! 123"` / `"SECRET"`).

### FR-12: Multi-Format Data Exporters
- **Description:** The system shall provide export utilities enabling users to:
  - Copy output ciphertext/plaintext directly to the OS clipboard with visual toast confirmation.
  - Download the result as a `.txt` file.
  - Export the complete Step-by-Step Execution Matrix as a comma-separated `.csv` file.

### FR-13: Dynamic Dark/Light Theme Engine
- **Description:** The UI shall support high-contrast dark and light color themes, persisting user preferences across browser sessions via the HTML5 `localStorage` API.

### FR-14: Responsive Multi-Screen Layout
- **Description:** The UI shall adapt gracefully across viewport widths:
  - Desktop (>900px): Balanced side-by-side two-column workspace.
  - Tablet (768px–900px): Stacked panels with dual-column statistical grids.
  - Mobile (<768px): Single-column vertical flow with full-width action controls.

### FR-15: Zero-Transmission Client Isolation
- **Description:** All cryptographic transformations, analytical tabulations, and file generation operations must execute entirely in the local browser runtime without outbound network requests.

## 4.5 Detailed Non-Functional Requirements

### NFR-01: Execution Latency and Computational Responsiveness
- The cryptographic engine shall process text payloads of up to 10,000 characters within less than 50 milliseconds on standard client hardware.
- UI state updates (statistical counters, validation messages) must reflect within 16 milliseconds to maintain a smooth 60 FPS rendering pipeline.

### NFR-02: Zero-Dependency Architecture
- The application shall contain zero external library dependencies (no jQuery, React, Vue, Bootstrap, Tailwind, or CDN web fonts).
- The system must function completely offline when opened directly from a local drive via file protocols.

### NFR-03: High Reliability and Fault Tolerance
- The system shall catch and handle all potential runtime exceptions gracefully. Under no circumstances should unhandled errors cause a blank screen or browser crash.

### NFR-04: Strict Privacy and Security by Design
- No user-entered messages, keys, or transformed results shall be logged, cached in remote servers, or transmitted over network sockets.

### NFR-05: Usability and Ergonomics
- The interface shall follow intuitive layout hierarchies, pairing clear typographic labels with distinct button colors: Emerald Green for Encryption, Sapphire Blue for Decryption, and Slate Gray for Neutral/Clear actions.

### NFR-06: Cross-Browser Portability
- The platform shall exhibit 100% feature parity across all major modern desktop and mobile browsers, including Google Chrome, Mozilla Firefox, Apple Safari, Microsoft Edge, and Opera.

### NFR-07: Web Accessibility (WCAG 2.1 AA Compliance)
- All interactive controls (buttons, textareas, selects) must possess valid ARIA labels, clear visible focus rings for keyboard navigation, and color contrast ratios exceeding 4.5:1 against adjacent backgrounds.

### NFR-08: Maintainability and Code Cleanliness
- JavaScript logic must be strictly decoupled into modular subsystems within an Immediately Invoked Function Expression (IIFE), preventing global namespace pollution.

### NFR-09: Modular Extensibility
- The architectural design must permit seamless future integration of automated cryptanalysis solvers, autokey variants, or WebAssembly modules without requiring structural refactoring.

### NFR-10: Educational Transparency
- Every computational transformation must expose its internal mathematical logic through inspectable DOM structures, facilitating transparent academic review.

## 4.6 Hardware, Software, and Environment Constraints

| Parameter | Minimum Requirement | Recommended Specification |
| :--- | :--- | :--- |
| **Processor (CPU)** | 1.0 GHz x86/ARM Dual-Core | 2.0 GHz Quad-Core or higher |
| **System Memory (RAM)** | 512 MB available RAM | 2 GB available RAM |
| **Storage Footprint** | < 1 MB local disk space | < 5 MB local disk space |
| **Display Resolution** | 320 × 480 (Mobile viewport) | 1920 × 1080 (Full HD Desktop) |
| **Operating System** | Platform Independent (Windows, macOS, Linux, Android, iOS) | Windows 10/11, macOS Sequoia, Ubuntu 24.04 LTS |
| **Web Browser** | ECMAScript 2015 (ES6) compatible browser | Chrome 120+, Firefox 120+, Safari 17+, Edge 120+ |
| **Network Connectivity** | Completely Offline (No internet required) | Completely Offline |

*Table 4.1: Hardware and Software Operating Environment Specifications.*

<div style="page-break-after: always;"></div>

---

# CHAPTER 5: SYSTEM ARCHITECTURE & DETAILED DESIGN

## 5.1 Architectural Design Pattern
The software architecture of the Vigenère Cipher platform implements a modern, client-side **Model-View-Controller (MVC)** design pattern, structurally decoupled within an event-driven single-page architecture.

```
+-------------------------------------------------------------------------------+
|                       CLIENT BROWSER EXECUTION CONTEXT                        |
+-------------------------------------------------------------------------------+
|                                                                               |
|  +-----------------------+                 +-------------------------------+  |
|  |         VIEW          |                 |          CONTROLLER           |  |
|  |  (HTML5 / CSS3 DOM)   | <============== |    (script.js Event Engine)   |  |
|  +-----------------------+   DOM Mutations +-------------------------------+  |
|  | - Message / Key Inputs|                 | - Event Listeners (Click/Input|  |
|  | - Mode Switcher Tabs  |                 | - Input Validation Router     |  |
|  | - Result Readout Box  |                 | - Raycast Ray Coordinator     |  |
|  | - Step Execution Table|                 | - Theme / Storage Coordinator |  |
|  | - 26x26 Tabula Recta  |                 +-------------------------------+  |
|  | - Live Stats Badges   |                                 |                  |
|  +-----------------------+                                 | Invokes Models   |
|              ^                                             v                  |
|              |                             +-------------------------------+  |
|              |                             |             MODEL             |  |
|              |                             |     (Pure Cryptographic Core) |  |
|              +---------------------------- +-------------------------------+  |
|                      State Projection      | - runVigenere(text, key, mode)|  |
|                                            | - generateTableauMatrix()     |  |
|                                            | - computeLexicalMetrics()     |  |
|                                            | - generateCryptoRandomKey()   |  |
|                                            +-------------------------------+  |
+-------------------------------------------------------------------------------+
```
*Figure 5.1: Client-Side Model-View-Controller (MVC) Architectural Topology.*

- **Model Layer:** Encapsulates pure, side-effect-free mathematical algorithms and data transformations. It contains the modular congruence arithmetic, keystream expansion mechanisms, statistical tokenizers, and matrix generation routines. The Model has zero awareness of the DOM or UI elements.
- **View Layer:** Composed of semantic HTML5 structural elements and CSS3 declarative rules. It provides visual containers for inputs, outputs, interactive tables, and analytical dashboards.
- **Controller Layer:** Acts as the mediating event bus. It binds browser event listeners (keystroke events, button triggers, hover coordinates), parses and sanitizes user input, dispatches commands to the Model, and efficiently updates the View via optimized DOM mutations.

## 5.2 High-Level Architectural Block Diagram
The system decomposes into eight specialized functional subsystems, coordinating through the central application controller:
1. **Input Ingestion & Sanitation Subsystem:** Strips whitespace from keys, validates minimum alphabetic thresholds, and triggers visual shake alerts upon invalid input.
2. **Cryptographic Core Subsystem:** Executes the forward ($+K$) and inverse ($-K$) modular congruence transformations over $\mathbb{Z}_{26}$.
3. **Trace Generation Engine:** Emits structured metadata objects capturing intermediate mathematical states for every character.
4. **Keystream Alignment Renderer:** Generates monospace, spatially synchronized comparative strings displaying the input, keystream, and output.
5. **Interactive Tabula Recta Generator:** Programmatically constructs the 26×26 matrix in the DOM and coordinates cross-highlighting on hover.
6. **Live Lexical Statistics Monitor:** Uses regular expressions to calculate real-time string metrics.
7. **Random Key Synthesizer:** Leverages pseudo-random generation to synthesize uniform alphabetic keys.
8. **Multi-Format Export Subsystem:** Serializes memory structures into CSV, TXT, or clipboard payloads using HTML5 Blob and Clipboard APIs.

## 5.3 Data Flow Diagrams (DFDs)

### 5.3.1 Level 0 Context DFD
The Level 0 Context DFD captures the entire application as a single process interacting with the external human user:

```
                  +----------------------------------------------+
                  |                                              |
                  |  [Plaintext / Ciphertext, Secret Key, Mode]  |
                  v                                              |
+----------+ ------------> +-----------------------------------+ | <------------ +----------+
|          |               |               0.0                 | |               |          |
|   USER   |               |   VIGENÈRE CIPHER APPLICATION     | |               |   USER   |
|          | <------------ |         SYSTEM PROCESS            | | ------------> |          |
+----------+  [Ciphertext, +-----------------------------------+ +--------------+ +----------+
               Decrypted Message, Step Trace Table, Stats, Files]
```
*Figure 5.2: Level 0 Context Data Flow Diagram.*

### 5.3.2 Level 1 Decomposition DFD
The Level 1 DFD decomposes the system into four major operational processes:

```
               [Raw Message, Key, Mode]
                          |
                          v
               +----------------------+
               |        1.0           |
               |   INPUT SANITATION   | <--- Rejection Alerts (Shake DOM)
               |     & VALIDATION     |
               +----------------------+
                          |
                          | [Sanitized Message, Clean Key]
                          v
               +----------------------+
               |        2.0           |
               |    CRYPTOGRAPHIC     | <--- Tabula Recta Lookup Reference
               |    TRANSFORMATION    |
               +----------------------+
                     /          \
                    /            \ [Trace Records]
    [Transformed   /              \
     Result]      v                v
         +----------------+   +-------------------+
         |      3.0       |   |        4.0        |
         | RESULT DISPLAY |   | STEP-BY-STEP      |
         | & EXPORT BLOB  |   | AUDIT GENERATOR   |
         +----------------+   +-------------------+
                 |                      |
                 v                      v
           [Output Box,           [Dynamic Process
            TXT/CSV Files]         Table, Raycast]
```
*Figure 5.3: Level 1 Decomposition Data Flow Diagram.*

### 5.3.3 Level 2 Subsystem Transformation DFD
The Level 2 DFD details the internal operations of Process 2.0 (Cryptographic Transformation):

```
[Sanitized Message] -------------------------------------------------------------+
                                                                                 |
[Clean Key] ---> [ 2.1 Key Stream Expander ] ---> [ Keystream Buffer ]           |
                                                            |                    |
                                                            v                    v
                                                 [ 2.2 Character Classifier ]
                                                 /                        \
                               [Alphabetic Token]                          [Non-Alpha Token]
                                      |                                           |
                                      v                                           v
                        [ 2.3 Modular Congruence ]                   [ 2.4 Invariant Passthrough ]
                        - Map Char to Z26 Value                      - Copy Char Unmodified
                        - Fetch Key Value from Stream                - Key Stream Index HELD
                        - C = (P + K) mod 26 (Encrypt)                            |
                        - P = (C - K + 26) mod 26 (Decrypt)                       |
                        - Preserve Original Case                                  |
                                      \                                           /
                                       v                                         v
                                   [ 2.5 Result String and Trace Aggregator ]
                                                       |
                                                       v
                                            [ Final Output & Steps ]
```
*Figure 5.4: Level 2 Subsystem Transformation Data Flow Diagram.*

## 5.4 UML Structural Design (Class and Module Structure)
Although implemented in functional ECMAScript 6, the system architecture maps cleanly into an object-oriented UML structural model:

```
+---------------------------------------------------------------------------------+
|                                 VigenereApp                                     |
+---------------------------------------------------------------------------------+
| - currentMode: String ("encrypt" | "decrypt")                                   |
| - currentStepsData: Array<StepRecord>                                           |
| - activeTheme: String ("dark" | "light")                                        |
+---------------------------------------------------------------------------------+
| + initApp(): void                                                               |
| + bindEvents(): void                                                            |
| + setMode(mode: String): void                                                   |
| + toggleTheme(): void                                                           |
| + handleClear(): void                                                           |
| + processCipher(mode: String): void                                             |
+---------------------------------------------------------------------------------+
                                       |
                                       +-----------------------+
                                       |                       |
                                       v                       v
+------------------------------------------+  +-----------------------------------+
|               CryptoEngine               |  |          TableauRenderer          |
+------------------------------------------+  +-----------------------------------+
| + validateInput(t: String, k: String): b |  | + generateTableau(): void         |
| + runVigenere(t: Str, k: Str, m: Str): O |  | + highlightTableau(r, c, m): void |
| + generateRandomKey(len: Number): String |  | + clearTableauHighlight(): void   |
+------------------------------------------+  +-----------------------------------+
                                       |
                                       +-----------------------+
                                       |                       |
                                       v                       v
+------------------------------------------+  +-----------------------------------+
|             StatisticsMonitor            |  |            ExportEngine           |
+------------------------------------------+  +-----------------------------------+
| + updateStatistics(): void               |  | + copyResult(): Promise<void>     |
| + computeMetrics(msg: Str, key: Str): Obj|  | + copySteps(): Promise<void>      |
+------------------------------------------+  | + downloadFile(data, name, type)  |
                                              | + downloadResult(): void          |
                                              | + downloadAnalysis(): void        |
                                              +-----------------------------------+
```
*Figure 5.5: Unified Modeling Language (UML) Component and Class Diagram.*

## 5.5 UML Sequence Diagrams

### 5.5.1 Sequence Diagram: Encryption Pipeline
Figure 5.6 details the operational sequence from user button click to DOM rendering:

```
User           UI/View             Controller          CryptoEngine         TableauView
 |                |                     |                    |                   |
 |--- Click ----->|                     |                    |                   |
 |    "Encrypt"   |--- OnClick Event -->|                    |                   |
 |                |                     |-- validateInput -->|                   |
 |                |                     |<-- isValid: true --|                   |
 |                |                     |                    |                   |
 |                |                     |-- runVigenere ---->|                   |
 |                |                     |   (P, K, "encrypt")|                   |
 |                |                     |                    |-- Expand Key ---- |
 |                |                     |                    |-- Modulo Math --- |
 |                |                     |<-- Return {Res, ---|                   |
 |                |                     |     Steps, Align} -|                   |
 |                |                     |                    |                   |
 |                |<-- Update Output ---|                    |                   |
 |                |<-- Render Alignment-|                    |                   |
 |                |<-- Build Step Table |                    |                   |
 |                |<-- Open Details ----|                    |                   |
 |                |                     |                    |                   |
```
*Figure 5.6: UML Sequence Diagram: Encryption Pipeline and Step Trace Construction.*

### 5.5.2 Sequence Diagram: Interactive Tableau Mouseover Raycasting
Figure 5.7 illustrates the coordinate raycasting event sequence triggered when a user hovers over an execution table row:

```
User           ProcessTableDOM         Controller           TableauDOM
 |                    |                     |                   |
 |--- MouseEnter ---->|                     |                   |
 |    Row (pos: 2)    |--- onMouseEnter --->|                   |
 |                    |    (inVal, kVal)    |                   |
 |                    |                     |-- clearHighlight >|
 |                    |                     |-- QuerySelector ->|
 |                    |                     |   Row Header      |
 |                    |                     |<-- rowHeader -----|
 |                    |                     |-- Add .highlight >|
 |                    |                     |                   |
 |                    |                     |-- QuerySelector ->|
 |                    |                     |   Col Header      |
 |                    |                     |<-- colHeader -----|
 |                    |                     |-- Add .highlight >|
 |                    |                     |                   |
 |                    |                     |-- Add .high-row ->|
 |                    |                     |-- Add .high-col ->|
 |                    |                     |-- Add .cell-high >|
 |                    |                     |                   |
```
*Figure 5.7: UML Sequence Diagram: Interactive Tableau Mouseover Raycasting.*

## 5.6 State Transition Model of the Cryptographic Engine
The system functions as a deterministic Finite State Machine (FSM), transitioning between five primary operational states:

```
  +--------------+        Init App        +--------------+
  |              | ---------------------> |              |
  | UNINITIALIZED|                        |     IDLE     | <---------------------+
  |              |                        |  (READY)     |                       |
  +--------------+                        +--------------+                       |
                                            |          ^                         |
                               User Enters  |          | User Corrects Input     |
                              Invalid Input |          |                         |
                                            v          |                         |
                                          +--------------+                       |
                                          |    ERROR     |                       |
                                          |  (SHAKING)   |                       |
                                          +--------------+                       |
                                            |                                    |
                               User Enters  |                                    |
                               Valid Input  |                                    |
                                            v                                    |
                                          +--------------+                       |
                                          |  PROCESSING  |                       |
                                          | (CALCULATING)|                       |
                                          +--------------+                       |
                                            |                                    |
                                 Compute    |                                    |
                                 Completed  v                                    |
                                          +--------------+                       |
                                          |   RENDERED   |                       |
                                          | (DISPLAYING) | ----------------------+
                                          +--------------+      Clear Clicked
```
*Figure 5.8: Finite State Machine (FSM) State Transition Diagram.*

## 5.7 User Interface Wireframes and Layout Grid Systems
The user interface is structured upon a flexible, responsive layout grid that transitions from a two-column desktop command center to a single-column mobile view:

```
+---------------------------------------------------------------------------------+
| [HEADER]  VIGENÈRE CIPHER: Interactive Polyalphabetic Tool          [THEME ☀️]  |
+---------------------------------------------------------------------------------+
| [WORKSPACE]                                                                     |
| +-------------------------------------+ +-------------------------------------+ |
| | LEFT PANEL: INPUT WORKBENCH         | | RIGHT PANEL: RESULTS & TELEMETRY    | |
| |                                     | |                                     | |
| | [ Mode Tabs: [ENCRYPT] [DECRYPT] ]  | | [ Output Label ]                    | |
| |                                     | | +---------------------------------+ | |
| | [ Message Label ]                   | | | Result Textarea (Read Only)     | | |
| | +---------------------------------+ | | +---------------------------------+ | |
| | | Message Textarea                | | |                                     | |
| | +---------------------------------+ | | [ Buttons: Copy | Download TXT/CSV ]| |
| |                                     | |                                     | |
| | [ Secret Key Label ]                | | [ Key Alignment Box ]               | |
| | +-----------------------------+---+ | | +---------------------------------+ | |
| | | Key Input Field             |👁️| | | | Input : ATTACK AT DAWN           | | |
| | +-----------------------------+---+ | | | Key   : LEMON  LE MON             | | |
| |                                     | | | Output: LXFOPV EF RNHR            | | |
| | [ Buttons: Encrypt | Decrypt | Clr]| | +---------------------------------+ | |
| |                                     | +-------------------------------------+ |
| | [ Random Key Generator Widget ]     |                                         |
| | [ Live Input Statistics Grid (6) ]  |                                         |
| +-------------------------------------+                                         |
+---------------------------------------------------------------------------------+
| [PREDEFINED EXAMPLES CARDS (3 Canonical Scenarios)]                             |
+---------------------------------------------------------------------------------+
| [COLLAPSIBLE DETAILS: STEP-BY-STEP PROCESS TABLE]                               |
| [COLLAPSIBLE DETAILS: INTERACTIVE 26x26 VIGENÈRE TABLEAU]                       |
| [COLLAPSIBLE DETAILS: MATHEMATICAL FOUNDATIONS & WORKED FORMULAS]               |
| [COLLAPSIBLE DETAILS: HISTORICAL & CRYPTANALYTIC BACKGROUND (About/Caesar/Risk)]|
+---------------------------------------------------------------------------------+
| [FOOTER: Privacy Notice (Client-Side Guarantee) | Educational Disclaimer]      |
+---------------------------------------------------------------------------------+
```

<div style="page-break-after: always;"></div>

---

# CHAPTER 6: ALGORITHMIC ENGINEERING & MATHEMATICAL FORMULATIONS

## 6.1 Formal Alphabetic Notation & Set Theory
To establish mathematical rigor, we define the computational domain using formal set theory and discrete mappings.

Let the canonical Latin alphabet be represented by the ordered set:
$$\\Sigma = \\{A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z\\}$$
where the cardinality $|\Sigma| = 26$.

We establish the bijection $\\phi: \\Sigma \\to \\mathbb{Z}_{26}$ mapping each uppercase character to its 0-indexed modular residue:

| $ch$ | $\\phi(ch)$ | $ch$ | $\\phi(ch)$ | $ch$ | $\\phi(ch)$ | $ch$ | $\\phi(ch)$ |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **A** | 0 | **H** | 7 | **O** | 14 | **V** | 21 |
| **B** | 1 | **I** | 8 | **P** | 15 | **W** | 22 |
| **C** | 2 | **J** | 9 | **Q** | 16 | **X** | 23 |
| **D** | 3 | **K** | 10 | **R** | 17 | **Y** | 24 |
| **E** | 4 | **L** | 11 | **S** | 18 | **Z** | 25 |
| **F** | 5 | **M** | 12 | **T** | 19 | | |
| **G** | 6 | **N** | 13 | **U** | 20 | | |

*Table 6.1: Numerical Representation of English Alphabet $\mathbb{Z}_{26}$.*

For lowercase letters, let $\\Sigma_{\\text{lower}} = \\{a, b, \\dots, z\\}$. We define $\\phi_{\\text{lower}}(ch) = \\text{ord}(ch) - 97$, mapping identically into $\\mathbb{Z}_{26}$.

## 6.2 Keystream Expansion & Modulo Indexing Mechanics
Let the plaintext message $M$ be a sequence of $N$ arbitrary characters:
$$M = (m_0, m_1, m_2, \\dots, m_{N-1})$$
where each character $m_i$ belongs to the universal character set $\\mathcal{U}$ (encompassing alphabetic letters, spaces, numerals, punctuation marks, and control characters).

Let the secret key $K$ be a non-empty string consisting of $L$ alphabetic characters:
$$K = (k_0, k_1, \\dots, k_{L-1}), \\quad \\text{where } k_j \\in \\Sigma, \\quad L = |K| \\ge 1$$

We convert the key string into a normalized numerical sequence over $\\mathbb{Z}_{26}$:
$$\\mathbf{k} = (\\kappa_0, \\kappa_1, \\dots, \\kappa_{L-1}), \\quad \\text{where } \\kappa_j = \\phi(\\text{toUpperCase}(k_j))$$

The critical operational challenge is constructing the expanded keystream sequence $\\mathbf{K}^* = (K_0^*, K_1^*, \\dots, K_{N-1}^*)$. Standard naive implementations advance the key index cyclically via $j = i \\pmod L$. However, this corrupts periodic cryptanalysis if non-alphabetic characters exist in the message.

In our engineered architecture, the keystream index $j$ is maintained as an independent state variable that increments **if and only if** the corresponding message character is alphabetic:
$$j(i) = \\left| \\{x \\in \\{0, 1, \\dots, i-1\\} \\mid m_x \\in \\Sigma \\cup \\Sigma_{\\text{lower}}\\} \\right| \\pmod L$$

Thus, for any character $m_i$:
- If $m_i \\in \\Sigma \\cup \\Sigma_{\\text{lower}}$, the keystream shift is:
  $$K_i^* = \\kappa_{j(i)}$$
- If $m_i \\notin \\Sigma \\cup \\Sigma_{\\text{lower}}$, the keystream character is undefined (passthrough), and the keystream state pointer is held constant:
  $$j(i+1) = j(i)$$

## 6.3 Mathematical Proof of Reversibility & Decryption Invariance
We now formalize the complete mathematical proof demonstrating that for any arbitrary plaintext string containing mixed case, spaces, and special symbols, the composition of decryption following encryption returns the exact original message.

**Theorem 6.1 (Global Cipher Invertibility):**  
*Let $\\mathcal{E}_K: \\mathcal{U}^* \\to \\mathcal{U}^*$ denote the Vigenère encryption operator under key $K$, and let $\\mathcal{D}_K: \\mathcal{U}^* \\to \\mathcal{U}^*$ denote the decryption operator under key $K$. Then:*
$$\\mathcal{D}_K(\\mathcal{E}_K(M)) = M, \\quad \\forall M \\in \\mathcal{U}^*$$

*Proof:*  
Let $M = (m_0, m_1, \\dots, m_{N-1})$. The transformation operates character-wise. Consider an arbitrary character $m_i$:

**Case 1: $m_i$ is non-alphabetic ($m_i \\notin \\Sigma \\cup \\Sigma_{\\text{lower}}$)**  
By definition of the invariant passthrough:
$$\\mathcal{E}_K(m_i) = m_i$$
Applying decryption to the result:
$$\\mathcal{D}_K(\\mathcal{E}_K(m_i)) = \\mathcal{D}_K(m_i) = m_i$$
Hence, non-alphabetic characters are perfectly preserved. Furthermore, the key pointer state $j(i)$ is held unchanged across both operations, ensuring keystream phase synchronization for all subsequent characters.

**Case 2: $m_i$ is an uppercase alphabetic character ($m_i \\in \\Sigma$)**  
Let $P_i = \\phi(m_i) = \\text{ord}(m_i) - 65 \\in \\mathbb{Z}_{26}$, and let $K_i^* = \\kappa_{j(i)} \\in \\mathbb{Z}_{26}$.  
The encryption operation calculates:
$$C_i = (P_i + K_i^*) \\pmod{26}$$
The encrypted character is $c_i = \\phi^{-1}(C_i) \\in \\Sigma$, which is uppercase.  
During decryption, since $c_i \\in \\Sigma$, the system computes:
$$P_i' = (C_i - K_i^* + 26) \\pmod{26}$$
Substituting the definition of $C_i$:
$$\\begin{aligned}
P_i' &= (((P_i + K_i^*) \\pmod{26}) - K_i^* + 26) \\pmod{26} \\\\
&\\equiv (P_i + K_i^* - K_i^* + 26) \\pmod{26} \\\\
&\\equiv (P_i + 26) \\pmod{26} \\\\
&\\equiv P_i \\pmod{26} = P_i
\\end{aligned}$$
Mapping back via $\\phi^{-1}$:
$$m_i' = \\phi^{-1}(P_i') = \\phi^{-1}(P_i) = m_i$$

**Case 3: $m_i$ is a lowercase alphabetic character ($m_i \\in \\Sigma_{\\text{lower}}$)**  
Let $P_i = \\phi_{\\text{lower}}(m_i) = \\text{ord}(m_i) - 97 \\in \\mathbb{Z}_{26}$.  
The encryption operation calculates $C_i = (P_i + K_i^*) \\pmod{26}$ and outputs $c_i = \\text{chr}(C_i + 97) \\in \\Sigma_{\\text{lower}}$, maintaining lowercase status.  
Decryption similarly calculates $P_i' = (C_i - K_i^* + 26) \\pmod{26} = P_i$, outputting $\\text{chr}(P_i + 97) = m_i$.

Because the theorem holds across all three cases for every index $i \\in \\{0, 1, \\dots, N-1\\}$, it follows that $\\mathcal{D}_K(\\mathcal{E}_K(M)) = M$. $\\blacksquare$

## 6.4 The Non-Alphabetic Invariant Axiom
In cryptographic engineering, the preservation of non-alphabetic glyphs must adhere to strict behavioral axioms:
1. **Structural Invariance:** Whitespace (spaces, tabs, newlines) and punctuation (commas, periods, quotation marks, hyphens) must maintain their exact spatial topology to preserve document formatting.
2. **Phase Invariance:** The keystream cycle must remain strictly bound to the linguistic content. Pausing keystream advancement on non-alphabetic tokens ensures that periodic cryptanalysis reflects purely linguistic coincidences rather than arbitrary punctuation intervals.

## 6.5 Algorithmic Pseudocode

### Algorithm 6.1: Key Validation and Sanitation
```text
FUNCTION validateAndSanitizeKey(rawKey: String) -> (Boolean, String):
    cleanKey = EMPTY_STRING
    FOR EACH char IN rawKey:
        IF (char >= 'A' AND char <= 'Z') OR (char >= 'a' AND char <= 'z'):
            cleanKey = cleanKey + toUpperCase(char)
    
    IF cleanKey.length == 0:
        RETURN (False, "Key must contain at least one alphabetic character.")
    
    RETURN (True, cleanKey)
END FUNCTION
```

### Algorithm 6.2: Complete Vigenère Transformation with Step-Trace Telemetry
```text
FUNCTION runVigenere(text: String, key: String, mode: String) -> (String, List<StepRecord>, String):
    isValid, cleanKey = validateAndSanitizeKey(key)
    IF NOT isValid:
        THROW ValidationError("Invalid Key")
        
    resultString = EMPTY_STRING
    stepsList = EMPTY_LIST
    expandedKeyList = EMPTY_LIST
    keyIndex = 0
    keyLength = cleanKey.length
    
    FOR i FROM 0 TO text.length - 1:
        char = text[i]
        
        IF isAlphabetic(char):
            isUpper = (char == toUpperCase(char))
            pVal = toUpperCase(char).charCodeAt(0) - 65
            
            kChar = cleanKey[keyIndex % keyLength]
            kVal = kChar.charCodeAt(0) - 65
            
            IF mode == "encrypt":
                cVal = (pVal + kVal) MOD 26
                calcString = "(" + pVal + " + " + kVal + ") mod 26 = " + cVal
            ELSE:
                cVal = (pVal - kVal + 26) MOD 26
                calcString = "(" + pVal + " - " + kVal + " + 26) mod 26 = " + cVal
                
            resChar = String.fromCharCode(cVal + 65)
            IF NOT isUpper:
                resChar = toLowerCase(resChar)
                
            resultString = resultString + resChar
            expandedKeyList.append(isUpper ? kChar : toLowerCase(kChar))
            
            step = StepRecord(
                position = i + 1,
                inputChar = char,
                inputValue = pVal,
                keyChar = kChar,
                keyValue = kVal,
                calculation = calcString,
                resultChar = resChar
            )
            stepsList.append(step)
            
            keyIndex = keyIndex + 1
        ELSE:
            resultString = resultString + char
            expandedKeyList.append(char == ' ' ? ' ' : '-')
            
            step = StepRecord(
                position = i + 1,
                inputChar = char,
                inputValue = "-",
                keyChar = "-",
                keyValue = "-",
                calculation = "Passthrough",
                resultChar = char
            )
            stepsList.append(step)
            
    expandedKeyString = join(expandedKeyList, "")
    RETURN (resultString, stepsList, expandedKeyString)
END FUNCTION
```

### Algorithm 6.3: Interactive Tabula Recta Dynamic Raycasting
```text
FUNCTION highlightTableau(pVal: Integer, kVal: Integer, mode: String):
    clearTableauHighlight()
    
    rowIdx = pVal
    colIdx = kVal
    
    // 1. Highlight the Row Header in the Tabula Recta tbody
    rowHeaderElement = tableau.querySelector("tbody tr:nth-child(" + (rowIdx + 1) + ") th")
    rowHeaderElement.classList.add("highlight")
    
    // 2. Highlight the Column Header in the Tabula Recta thead
    colHeaderElement = tableau.querySelector("thead th:nth-child(" + (colIdx + 2) + ")")
    colHeaderElement.classList.add("highlight")
    
    // 3. Highlight all horizontal cells across the target row
    rowCells = tableau.querySelectorAll("tbody tr:nth-child(" + (rowIdx + 1) + ") td")
    FOR EACH cell IN rowCells:
        cell.classList.add("highlight-row")
        
    // 4. Highlight all vertical cells down the target column
    allRows = tableau.querySelectorAll("tbody tr")
    FOR EACH tr IN allRows:
        colCell = tr.querySelector("td:nth-child(" + (colIdx + 2) + ")")
        colCell.classList.add("highlight-col")
        
    // 5. Highlight the primary coordinate intersection cell
    targetCell = tableau.querySelector("td[data-r='" + rowIdx + "'][data-c='" + colIdx + "']")
    targetCell.classList.add("highlight")
END FUNCTION
```

## 6.6 Flowchart Representation of Cryptographic Pipeline

```
                              [ START: processCipher(mode) ]
                                            |
                                            v
                             [ Fetch Message and Key Strings ]
                                            |
                                            v
                                < Is Message Empty? >
                               /                     \
                             YES                      NO
                             /                         \
            [ Show Shake Error: Message ]                v
                                               < Is Key Alphabetic? >
                                              /                      \
                                            NO                       YES
                                            /                         \
                            [ Show Shake Error: Key ]                  v
                                                         [ Clean Key -> Uppercase ]
                                                         [ Init i = 0, keyIdx = 0 ]
                                                                       |
+----------------------------------------------------------------------+
|
v
< Is i < Message.length? > -------- YES -------> < Is Message[i] Alphabetic? >
|                                               /                           \
NO                                            YES                            NO
|                                             /                               \
|                 [ pVal = charCode - Base ]           [ Output[i] = Message[i] ]
|                 [ kChar = Key[keyIdx % Len] ]        [ ExpandedKey[i] = '-'   ]
|                 [ kVal = kChar - 65 ]                [ Step = 'Passthrough'   ]
|                 [ Mode == Encrypt ?                  [ Keep keyIdx unchanged  ]
|                   cVal = (pVal + kVal) % 26 :                        |
|                   cVal = (pVal - kVal + 26) % 26 ]                   |
|                 [ Record Calculation String ]                        |
|                 [ Output[i] = FromCharCode ]                         |
|                 [ keyIdx = keyIdx + 1 ]                              |
|                                     \                                /
|                                      v                              v
|                                    [ Append to Result & Step List ]
|                                    [ Increment i = i + 1 ]
|                                              |
+----------------------------------------------+
|
v
[ Render Output Textarea ]
[ Render Monospace Key Alignment ]
[ Render Process Steps Table with Raycast Listeners ]
[ Expand Details Accordion ]
|
v
[ END: Await User Interaction ]
```
*Figure 6.1: Flowchart of the Complete Vigenère Transformation Algorithm.*

## 6.7 Computational Complexity Analysis

### 6.7.1 Time Complexity Analysis
Let $N$ denote the total number of characters in the message string ($N = |M|$), and let $L$ denote the length of the secret key ($L = |K|$).

1. **Key Sanitization:** Traversing the raw key to strip non-alphabetic characters requires scanning $L$ characters: $O(L)$ operations.
2. **Main Transformation Loop:** The algorithm executes a single `for` loop iterating exactly $N$ times. Within each iteration:
   - Character classification (`/[a-zA-Z]/`) executes in $O(1)$ constant time.
   - ASCII character code conversions (`charCodeAt`, `fromCharCode`) execute in $O(1)$.
   - Modular arithmetic addition, subtraction, and modulo operations execute in $O(1)$.
   - Keystream index incrementation and modulo indexing (`keyIndex % cleanKey.length`) execute in $O(1)$.
   - Instantiation of the `StepRecord` object executes in $O(1)$.
3. **Total Time Cost:**  
   $$T(N, L) = O(L) + N \\times O(1) = O(N + L)$$
   In all practical scenarios, key length is substantially smaller than message length ($L \\ll N$). Therefore, the overall asymptotic time complexity simplifies to:
   $$\\Theta(N)$$
   The algorithm exhibits strictly **linear time complexity**, representing the optimal theoretical lower bound for processing an arbitrary text stream.

### 6.7.2 Space Complexity Analysis
1. **Result Buffer:** Storing the resulting transformed string requires allocating a character buffer of length $N$: $O(N)$ auxiliary space.
2. **Expanded Keystream Buffer:** Storing the visual alignment keystream array requires $N$ elements: $O(N)$ space.
3. **Execution Steps Array:** Storing the structured trace records requires an array of $N$ objects, each containing fixed scalar properties: $O(N)$ space.
4. **Total Space Cost:**  
   $$S(N) = O(N) + O(N) + O(N) = O(N)$$
   The auxiliary memory footprint scales strictly linearly with input payload size. For a 10,000-character document, total memory consumption remains under 2 megabytes, well within standard browser allocations.

<div style="page-break-after: always;"></div>
"""
