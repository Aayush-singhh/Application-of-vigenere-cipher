# Vigenère Cipher Algorithm

## 1. Vigenère Cipher Algorithm Overview
The Vigenère cipher is a method of encrypting alphabetic text by using a series of interwoven Caesar ciphers, based on the letters of a keyword. It is a form of polyalphabetic substitution. First described by Giovan Battista Bellaso in 1553, it was famously misattributed to Blaise de Vigenère in the 19th century.

## 2. Mathematical Foundation
The algorithm relies on modular arithmetic and a 0-indexed mapping of the English alphabet.
Letters are mapped as follows:
`A=0, B=1, C=2, ..., Z=25`

This mapping allows us to treat letters as numbers, perform arithmetic operations, and map the results back to letters.

## 3. Encryption Algorithm
The encryption process shifts each letter of the plaintext by an amount determined by the corresponding letter of the keyword.

**Formula:**
`C = (P + K) mod 26`
Where `C` is ciphertext, `P` is plaintext, and `K` is the key.

**Pseudocode:**
```text
function encrypt(plaintext, key):
    ciphertext = ""
    key_index = 0
    key = toUpperCase(key)
    
    for each character 'char' in plaintext:
        if isLetter(char):
            // Determine base (65 for 'A', 97 for 'a')
            base = isUpperCase(char) ? 65 : 97
            
            // Convert to 0-25 index
            P = ascii(char) - base
            K = ascii(key[key_index % key.length]) - 65
            
            // Encrypt and convert back to ASCII
            C = (P + K) % 26
            ciphertext += charFromAscii(C + base)
            
            // Move to next key letter
            key_index++
        else:
            // Non-letters remain unchanged
            ciphertext += char
            
    return ciphertext
```

## 4. Decryption Algorithm
Decryption reverses the process by subtracting the key value from the ciphertext value.

**Formula:**
`P = (C - K + 26) mod 26`

**Pseudocode:**
```text
function decrypt(ciphertext, key):
    plaintext = ""
    key_index = 0
    key = toUpperCase(key)
    
    for each character 'char' in ciphertext:
        if isLetter(char):
            base = isUpperCase(char) ? 65 : 97
            
            C = ascii(char) - base
            K = ascii(key[key_index % key.length]) - 65
            
            // Decrypt and convert back to ASCII
            P = (C - K + 26) % 26
            plaintext += charFromAscii(P + base)
            
            key_index++
        else:
            plaintext += char
            
    return plaintext
```

## 5. Key Expansion/Repetition Mechanism
If the keyword is shorter than the plaintext, it is repeated to match the length of the alphabetic characters in the text.
For example, if text is "MESSAGE" (7 letters) and key is "KEY" (3 letters), the expanded key conceptually becomes "KEYKEYK". The algorithm handles this efficiently using modulo arithmetic on the key index: `key[key_index % key.length]`. Note that the `key_index` only increments when an alphabetic character is processed.

## 6. Character Handling Rules
- **Alphabetic Characters**: Processed through the encryption/decryption formula.
- **Non-Alphabetic Characters**: Spaces, punctuation, and numbers are appended directly to the output without modification. The key index is NOT incremented when a non-alphabetic character is encountered, maintaining the alignment of the key with the alphabetic text.

## 7. Case Preservation Logic
The algorithm checks the ASCII range of the input character to determine its case before processing.
- If `char >= 'A'` and `char <= 'Z'`, the base is 65.
- If `char >= 'a'` and `char <= 'z'`, the base is 97.
The mathematical shift is performed on the 0-25 index, and the original base is added back, ensuring the output case matches the input case.

## 8. Complete Worked Example
**Text:** `ATTACKATDAWN`
**Key:** `LEMON`

1. A(0) + L(11) = 11 -> **L**
2. T(19) + E(4) = 23 -> **X**
3. T(19) + M(12) = 31 % 26 = 5 -> **F**
4. A(0) + O(14) = 14 -> **O**
5. C(2) + N(13) = 15 -> **P**
6. K(10) + L(11) = 21 -> **V**
7. A(0) + E(4) = 4 -> **E**
8. T(19) + M(12) = 31 % 26 = 5 -> **F**
9. D(3) + O(14) = 17 -> **R**
10. A(0) + N(13) = 13 -> **N**
11. W(22) + L(11) = 33 % 26 = 7 -> **H**
12. N(13) + E(4) = 17 -> **R**

**Ciphertext:** `LXFOPVEFRNHR`

## 9. Performance Analysis
- **Time Complexity**: O(n), where n is the length of the input text. The algorithm processes each character exactly once. The operations inside the loop (arithmetic, ASCII conversion) take O(1) constant time.
- **Space Complexity**: O(n). A new string of length n is constructed to hold the ciphertext/plaintext.

## 10. Comparison with Caesar Cipher
The Caesar cipher is a monoalphabetic substitution cipher that uses a single shift value for the entire message. It is highly vulnerable to frequency analysis.
The Vigenère cipher is polyalphabetic, utilizing multiple Caesar ciphers in sequence determined by a keyword. This smooths out the letter frequencies in the ciphertext, making standard frequency analysis ineffective and making it significantly stronger than the Caesar cipher.

## 11. Security Analysis
While considered "le chiffre indéchiffrable" (the indecipherable cipher) for 300 years, it is trivial to break today.
- **Kasiski Examination**: Discovered in 1863, this method finds repeated sequences in the ciphertext to deduce the likely length of the keyword.
- **Friedman Test**: Uses the Index of Coincidence to statistically determine the key length.
- **Frequency Analysis**: Once the key length `L` is known, the ciphertext is broken into `L` interwoven Caesar ciphers. Standard frequency analysis can then be applied to each individual Caesar cipher to reveal the keyword and plaintext.

## 12. Historical Context
The Vigenère cipher was described in 1553 by Giovan Battista Bellaso. It was later misattributed to Blaise de Vigenère in the 19th century. It was widely used in military and diplomatic communications due to its perceived unbreakability until Charles Babbage and Friedrich Kasiski developed reliable methods to crack it in the mid-19th century.
